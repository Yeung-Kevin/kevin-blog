<template>
    <!-- <div class="shopping-cart-wrap" style="display: none;">
         <h3 class="shopping-cart-tit" style="padding-top: 15px">我的购物车</h3>
         <div style="text-align: center; padding-top: 190px; padding-bottom: 350px">
             <img src="" width="272" height="185" alt="">
             <span class="null-text">购物车竟然是空的 “再忙，也记得要<a style="color: #4990E2">充实</a>自己”</span>
         </div>
     </div>-->
    <div class="shopping-cart-wrap">
        <h3 class="shopping-cart-tit">我的购物车
            <small>共<span>2</span>门课程</small>
        </h3>
        <div class="cart-table">
            <table class="table shopping-cart-list">
                <thead class="shopping-cart-list-head" style="background: #F7F7F7; width: 100%; height: 80px">
                <tr class="shopping-cart-list-head-wrap" style="background: #F7F7F7; width: 100%">
                    <th class="shopping-cart-list-head-item" width="8%"></th>
                    <th class="shopping-cart-list-head-item" width="50%">课程</th>
                    <th class="shopping-cart-list-head-item" width="20%">有效期</th>
                    <th class="shopping-cart-list-head-item" width="15%">单价</th>
                    <th class="shopping-cart-list-head-item" width="15%">操作</th>
                </tr>
                </thead>
                <tbody> <!--v-for-start-->
                <tr v-for="(val, index) in course_list" :key="index">
                    <td width="8%" class="pad-left">
                        <input class="check J-check-btn" type="checkbox" :id="`color-input${index}`" v-bind:value="val.course_id" v-model="course_id_list">
                        <label :for="`color-input${index}`">
                            <img src="./img/hook.svg" alt="">
                        </label>
                    </td>
                    <td width="50%">
                        <img alt="" class="product-img" :src="val.img">
                        <a class="shopping-cart-course-title" href="/courses/105/details-introduce">{{ val.name }}</a>
                    </td>
                    <td width="20%">
                        <select class="select-option" name="datetime" v-model="val.price_policy_id" @change="select_change(val.course_id, index)">
                            <option value="10000" selected="" v-for="(price, j) in val.price_policy" v-bind:value="price.id">
                                {{ price.valid_period_txt }}
                            </option>
                        </select>
                    </td>
                    <td width="15%" class="shopping-cart-course-price">¥{{ val.price }}</td>
                    <td width="15%" style="text-align: left;position: relative">
                        <button class="do-btn" @click="isShowDel(index)">删除</button>
                        <div class="delete-wrap" v-show="index === del_index">
                            <div style="padding: 20px 0 24px 20px">
                                <img src="" width="14" height="14" alt="">
                                <span class="delete-text" style="display: inline-block; margin-left: 10px">你确定删除该课程吗？</span>
                            </div>
                            <div class="delete-btn-wrap">
                                <button class="delete-cancel" @click="cancleDel">取消</button>
                                <button class="delete-sure" @click="confirmDel(val.course_id, index)">确定</button>
                            </div>
                        </div>
                    </td>
                </tr>
                </tbody>
            </table>
            <ul style="width: 100%; height: 80px; background: #F7F7F7; margin-bottom: 300px;margin-top:50px; display: flex; align-items: center">
                <li class="charge-list">
                    <input class="select_all" id="color-input-red" type="checkbox" width="20px" height="20px">
                    <label for="color-input-red">
                        <img src="./img/hook.svg" alt="">
                    </label>
                    <span class="shopping-cart-bot-font" style="margin-left: 15px; cursor: pointer">全选</span>
                </li>
                <li class="charge-list" style="margin-left: 58px">
                    <img src="" width="18" height="auto" alt="">
                    <span class="shopping-cart-bot-font" style="margin-left: 15px; cursor: pointer">删除</span>
                </li>
                <li class="charge-list" style="margin-left: auto">
                    <span class="shopping-cart-bot-font" style="margin-right: 62px">总计：¥399.0</span>
                    <button class="go-charge-btn" @click="settlement">去结算</button>
                </li>
            </ul>
        </div>
    </div>
</template>

<script>
    import {reqShoppingCart, reqEditCart, reqDelCart, goSettlement} from "../../api";

    export default {
        name: "ShoppingCart",
        data() {
            return {
                course_list: [],
                del_index: '',
                course_id_list: []
            }
        },
        methods: {
            // 获取购物车
            async get_shopping_cart(id) {
                const course_obj = await reqShoppingCart();
                this.course_list = course_obj.data;
            },
            // 修改购物车
            async select_change(course_id, index) {
                let data = {
                    course_id,
                    price_policy_id: this.course_list[index].price_policy_id,
                };
                const res = await reqEditCart(data);
                console.log(res)
            },
            isShowDel(index) {
                this.del_index = index
            },
            cancleDel() {
                this.del_index = ''
            },
            // 删除所选课程
            async confirmDel(id, index) {
                let data = {course_id: id};
                const res = await reqDelCart({data});
                if (res.code) {
                    this.course_list.splice(index, 1);
                    this.del_index = ''
                }
            },
            // 结算
            async settlement() {
                const {course_id_list} = this;
                const res = await goSettlement({course_id_list});
                this.$router.push({name: 'buy'})
            }
        },
        mounted() {
            this.get_shopping_cart()
        }
    }
</script>

<style scoped>
    .table > thead > tr > th {
        height: 80px;
        line-height: 80px;
        padding: 0 0 0 10px;
        text-align: left;
    }

    .table > tbody > tr > td, .table > tbody > tr > th, .table > thead > tr > td, .table > thead > tr > th {
        border-top: none !important
    }

    .table > tbody > tr {
        border-bottom: 1px solid #ddd
    }

    .table > tbody > tr:last-child {
        border-bottom: none
    }

    .delete-more-wrap {
        display: none
    }

    .shadow-wrap {
        width: 100%;
        height: 100%;
        position: fixed;
        top: 0;
        left: 0;
        z-index: 101
    }

    .login-shadow {
        background: rgba(0, 0, 0, .2) !important
    }

    .delete-more-tip {
        width: 416px;
        height: 228px;
        background: #fff;
        box-shadow: 0 2px 8px 0 rgba(0, 0, 0, .2);
        border-radius: 4px;
        text-align: center;
        position: relative;
        top: 50%;
        left: 50%;
        margin-top: -114px;
        margin-left: -208px;
        padding: 40px
    }

    .delete-more-tit {
        font-size: 14px;
        color: #666;
        line-height: 21px;
        margin: 0 0 0 16px
    }

    .delete-more-dec {
        text-align: left;
        height: 70px;
        margin: 10px 0 16px 40px;
        font-size: 12px;
        color: #666;
        line-height: 21px
    }

    .delete-more-btn {
        width: 65px !important;
        height: 32px !important;
        font-size: 14px !important;
        line-height: 21px !important
    }

    .delete-wrap {
        width: 211px;
        height: 116px;
        position: absolute;
        top: 0;
        left: -3px;
        background: url(./img/tip-panel.8098a03.png) no-repeat;
        background-size: 100% 100%;
    }

    .delete-text {
        font-size: 12px;
        color: #666;
        line-height: 18px
    }

    .delete-btn-wrap {
        text-align: right;
        padding-right: 20px
    }

    .delete-cancel, .delete-sure {
        width: 44px;
        height: 27px;
        outline: none;
        border-radius: 4px;
        font-size: 12px;
        line-height: 18px;
        cursor: pointer;
    }

    .delete-cancel {
        background: none;
        border: 1px solid #d9d9d9;
        color: #666
    }

    .delete-sure {
        background: #108ee9;
        border: none;
        color: #fff;
        margin-left: 4px
    }

    .null-text {
        display: block;
        margin-top: 50px;
        font-size: 20px;
        color: #c5c3c3;
        cursor: pointer;
        letter-spacing: .32px
    }

    .null-text > a:hover {
        text-decoration: none
    }

    .charge-list {
        display: -ms-flexbox;
        display: flex;
        -ms-flex-align: center;
        align-items: center;
        list-style: none
    }

    .select_all {
        width: 20px;
        height: 20px
    }

    .pad-left {
        padding-left: 25px !important
    }

    .table > tbody > tr > td {
        padding: 35px 10px;
        vertical-align: middle !important
    }

    .table > thead > tr > th {
        vertical-align: middle !important;
        border-bottom: none !important;
        font-weight: 400 !important
    }

    .shopping-cart-wrap {
        width: 1200px;
        margin: 0 auto
    }

    .shopping-cart-tit {
        font-size: 18px;
        color: #666;
        margin: 25px 0
    }

    .shopping-cart-tit small {
        font-size: 12px;
        color: #d0d0d0;
        display: inline-block
    }

    .shopping-cart-list-head-item {
        font-size: 14px;
        color: #333;
        height: 80px
    }

    .shopping-cart-course-price {
        font-size: 16px;
        color: #333;
        letter-spacing: .36px
    }

    .do-btn {
        border: none;
        outline: none;
        background: none;
        font-size: 14px;
        color: #ffc210;
        margin-right: 15px;
        cursor: pointer;
    }

    .cart-table {
        width: 1200px;
    }

    table {
        width: 100%;
    }

    tr {
        width: 100%
    }

    td, tr {
        display: -ms-flexbox;
        display: flex
    }

    td {
        -ms-flex-align: center;
        align-items: center
    }

    .product-img {
        width: 175px;
        height: 115px;
        margin-right: 35px
    }

    .shopping-cart-course-title {
        font-size: 16px;
        color: #333;
        letter-spacing: .36px;
        text-decoration: none
    }

    .select-option {
        font-size: 12px;
        color: #666;
        line-height: 18px;
        width: 117px;
        height: 28px;
        padding-left: 16px;
        border: 1px solid #d9d9d9;
        border-radius: 4px
    }

    .go-charge-btn {
        width: 159px;
        height: 80px;
        outline: none;
        border: none;
        background: #ffc210;
        font-size: 18px;
        color: #fff
    }

    .shopping-cart-bot-font {
        font-size: 18px;
        color: #666
    }

    input[type=checkbox] {
        visibility: hidden
    }

    #color-input-red + label, .pad-left > input + label {
        display: block;
        width: 16px;
        height: 16px;
        cursor: pointer;
        border: 1px solid #9b9b9b;
        background: transparent;
        margin-bottom: 0;
        display: -ms-flexbox;
        display: flex;
        -ms-flex-align: center;
        align-items: center;
        -ms-flex-pack: center;
        justify-content: center;
        margin-right: 8px
    }

    #color-input-red:checked + label, .pad-left > input:checked + label {
        background: #ffc210;
        border: none
    }
</style>
