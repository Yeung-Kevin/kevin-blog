<template>
    <div class="purchase-wrap">
        <table class="table shopping-cart-list" style="table-layout:fixed">
            <thead class="shopping-cart-list-head" style="background: #F7F7F7; width: 100%; height: 80px">
            <tr class="shopping-cart-list-head-wrap" style="background: #F7F7F7; width: 100%">
                <th class="head-item" width="60%">课程</th>
                <th class="head-item" width="10%">有效期</th>
                <th class="head-item" width="10%">原价</th>
                <th class="head-item" width="10%">优惠券</th>
                <th class="head-item" width="10%">折后价</th>
            </tr>
            </thead>
            <tbody> <!--v-for-start-->
            <tr v-for="(v, i) in course_coupons" :key="i">
                <td width="60%">
                    <img alt=" " class="product-img" :src="v.course_info.img">
                    <a class="course-title" href="/courses/105/details-introduce">{{ v.course_info.name }}</a>
                </td>
                <td width="10%" class="course-str">{{ v.course_info.valid_period_txt }}</td>
                <td width="10%" class="course-str">¥{{ v.course_info.price }}</td>
                <td width="10%">
                    <select class="select-option" name="coupon" v-model="v.course_info.default" @change="edit_buy"> <!--v-for-start-->
                        <option>请选择</option><!--v-for-end-->
                        <option v-for="(c, j) in v.coupons" :key="j" v-bind:value="c.id">{{ c.name }}</option>
                    </select>
                </td>
                <td width="10%" class="course-str">¥{{ ad_price[v.course_info.course_id] }}</td>
            </tr>
            </tbody>
        </table>
        <div style="text-align: right; margin-top: 30px">
            <div id="accordion">
                <div style="text-align: left; display: flex;padding-bottom: 22px;padding-left:30px;border-bottom: 1px solid #e8e8e8">
                    <div style="display: flex">
                        <span class="select-coupon">使用优惠劵：</span>
                        <a data-toggle="collapse" data-parent="#accordion" href="#collapseOne" style="width: 20px; height: 20px" class="" aria-expanded="true">
                            <img class="sign rotate" src="./img/coupon-select-icon.79a556b.png" width="20" height="20" alt="">
                        </a>
                        <span class="coupon-num">有{{ global_coupons.length }}张可用</span>
                    </div>
                    <p class="sum-price-wrap" style="margin-right: 45px">商品总金额：<span class="sum-price">{{ total_price }}元</span></p>
                </div>
                <div style="text-align: left;" id="collapseOne" class="panel-collapse out collapse in" aria-expanded="true">

                    <select name="global_coupon" class="g-coupon-option" v-model="global_coupon_id" v-if="global_coupons.length" @change="edit_buy">
                        <option>请选择</option>
                        <option v-for="(v, i) in global_coupons" :key="i" v-bind:value="v.id">{{v.name}}</option>
                    </select>

                    <div v-else style="text-align: center; width: 100%; padding: 50px 0px; align-items: center; justify-content: center; border-bottom: 1px solid rgb(232, 232, 232);">
                        <span style="font-size: 16px; color: #9b9b9b">暂无可用优惠券</span>
                    </div>
                </div>
            </div>
            <!--<div style="height: 30px; margin-top: 40px; display: flex; align-items: center; justify-content: flex-end">
                <input type="checkbox" class="ok" id="color-input-red">
                <label for="color-input-red"><img src="./img/hook.svg" alt=""></label>
                <p class="discount-num" style="color:#9B9B9B">使用我的贝里</p>
                <p class="discount-num" style="margin-right: 45px"><span style="display: none;">可用0个已抵扣 ￥0</span></p>
            </div>-->
            <p class="sun-coupon-num" style="margin-right: 45px;margin-bottom:43px">优惠券抵扣：<span>{{ deduction }}元</span></p>
        </div>
        <ul class="pad-left">
            <div class="left"><span>支付方式：</span>
                <div class="paytype">
                    <li class="payment bor"><img src="./img/zfb.0a21430.svg" alt="" class="img1">
                        <span>支付宝</span> <img src="./img/wx-selected.b759a41.svg" alt="" class="icon">
                    </li>
                    <li class="payment"><img src="./img/wx.52a4c49.svg" alt="" class="img1">
                        <span>微信</span> <img src="./img/wx-selected.b759a41.svg" alt="" class="icon" style="display: none;">
                    </li>
                </div>
            </div>
            <li class="pay"><span class="bot-font-small"> 实付款： <span class="true-price">¥{{ real_payment }}</span><!--v-if--> <!--v-if--> </span>
                <button class="go-buy-btn" @click="click_pay">立即支付</button>
            </li>
        </ul>
    </div>
</template>

<script>
    import {reqBuy, reqEditBuy, pay} from '../../api'

    export default {
        name: "Buy",
        data() {
            return {
                course_coupons: [],
                global_coupons: [],
                total_price: 0,
                real_payment: 0,
                ad_price: {},
                global_coupon_id: '请选择',
                deduction: 0
            }
        },
        watch: {
            course_coupons: {
                handler(newData, oldData) {
                    let ad_price_obj = {};
                    newData.map(obj => {
                        ad_price_obj[obj.course_info.course_id] = obj.course_info.price;
                    });
                    this.ad_price = ad_price_obj;
                },
                deep: true
            }
        },
        methods: {
            async get_buy_info() {
                const res = await reqBuy();
                this.course_coupons = res.data.course_coupons;
                this.global_coupons = res.data.global_coupons;
                this.total_price = res.data.total_price;
                this.real_payment = res.data.real_payment;
            },
            async edit_buy() {
                let data = {
                    choose_coupons: {},
                    global_coupon_id: ''
                };
                this.course_coupons.map(obj => {
                    const course_info = obj.course_info;
                    data.choose_coupons[course_info.course_id.toString()] = course_info.default === '请选择' ? '' : course_info.default;
                });
                data.global_coupon_id = this.global_coupon_id === '请选择' ? '' : this.global_coupon_id;

                const res = await reqEditBuy(data);
                this.total_price = res.data.total_price;
                this.real_payment = res.data.real_payment;
                this.ad_price = res.data.ad_price_list;
                this.deduction = res.data.deduction;
            },
            async click_pay() {
                let course_list = this.course_coupons.map(obj => {
                    console.log(obj);
                    const course_id = obj.course_info.course_id;
                    return {
                        course_id,
                        default_price_policy_id: obj.course_info.price_policy_id,
                        coupon_record_id: obj.course_info.default === '请选择' ? '' : obj.course_info.default,
                        original_price: obj.course_info.price,  // 原价
                        price: this.ad_price[course_id], // 折后价
                        valid_period_display: obj.course_info.valid_period_txt,
                    }
                });

                let data = {
                    course_list,
                    global_coupon_id: this.global_coupon_id === '请选择' ? '' : this.global_coupon_id,
                    pay_money: this.real_payment,
                    deductible_amount: this.deduction,
                };

                const res = await pay(data);
                const alipay_url = res.data.url;

                window.location.href = alipay_url;
            }
        },
        mounted() {
            this.get_buy_info()
        }
    }
</script>

<style scoped>
    .table > thead > tr > th {
        height: 80px;
        line-height: 80px;
        /*padding: 0 0 0 10px;*/
        text-align: left;
    }

    .table > tbody > tr > td, .table > tbody > tr > th, .table > thead > tr > td, .table > thead > tr > th {
        border-top: none !important;
        box-sizing: border-box;
    }

    .table > tbody > tr {
        border-bottom: 1px solid #ddd
    }

    .table > tbody > tr:last-child {
        border-bottom: none
    }

    .table > tbody > tr > td {
        padding: 35px 10px;
        vertical-align: middle !important
    }

    .table > thead > tr > th {
        vertical-align: middle !important;
        border-bottom: none !important;
        font-weight: 400 !important
    }

    table {
        width: 100%;
    }

    tr {
        width: 100%
    }

    td, tr {
        display: -ms-flexbox;
        display: flex
    }

    td {
        -ms-flex-align: center;
        align-items: center
    }

    .purchase-wrap {
        width: 1200px;
        margin: 0 auto;
    }

    .product-img {
        width: 175px;
        height: 115px;
        margin-right: 35px
    }

    .course-title {
        font-size: 16px;
        color: #333;
        letter-spacing: .36px;
        text-decoration: none
    }

    .select-option {
        font-size: 12px;
        color: #666;
        line-height: 18px;
        width: 117px;
        height: 28px;
        padding-left: 16px;
        border: 1px solid #d9d9d9;
        border-radius: 4px
    }

    .head-item {
        font-size: 14px;
        color: #333;
        height: 80px;
        text-align: center !important;
    }

    .course-str {
        justify-content: center;
    }

    .sum-price-wrap {
        display: inline-block;
        margin-left: auto;
        font-size: 16px;
        color: #4a4a4a;
        font-family: PingFangSC-Medium;
    }

    .sum-price {
        font-family: PingFangSC-Medium;
        font-size: 18px;
        color: #fa6240;
    }

    .coupon-num {
        height: 22px;
        line-height: 22px;
        padding: 0 5px;
        text-align: center;
        margin-left: 14px;
        font-family: PingFangSC-Regular;
        font-size: 12px;
        color: #fff;
        letter-spacing: .27px;
        display: inline-block;
        background: #fa6240;
        border-radius: 2px;
        margin-left: 20px;
    }

    .ok {
        display: block;
        width: 15px;
        height: 15px;
        cursor: pointer;
        margin-top: -2px !important;
    }

    input[type=checkbox] {
        visibility: hidden;
    }

    #color-input-red + label {
        display: block;
        width: 16px;
        height: 16px;
        cursor: pointer;
        border: 1px solid #9b9b9b;
        background: transparent;
        margin-bottom: 0;
        display: -ms-flexbox;
        display: flex;
        -ms-flex-align: center;
        align-items: center;
        -ms-flex-pack: center;
        justify-content: center;
        margin-right: 8px;
    }

    #color-input-red:checked + label {
        background: #f5a623;
        border: none;
    }

    .sun-coupon-num {
        margin-top: 40px;
        font-size: 16px;
        color: #4a4a4a;
        display: inline-block;
    }

    .sun-coupon-num span {
        font-size: 18px;
        color: #fa6240;
    }

    .pad-left .left, .pad-left {
        display: -ms-flexbox;
        display: flex;
        -ms-flex-align: center;
        align-items: center
    }

    .pad-left {
        width: 1200px;
        margin-bottom: 180px;
        -ms-flex-pack: justify;
        justify-content: space-between;
        position: relative;
    }

    .pad-left .left .payment, .pad-left .left .paytype {
        display: -ms-flexbox;
        display: flex;
        -ms-flex-align: center;
        align-items: center
    }

    .pad-left .left .payment {
        width: 120px;
        height: 48px;
        border-radius: 2.64px;
        margin-right: 36px;
        border: 1px solid #e9e9e9;
        -ms-flex-pack: center;
        justify-content: center;
        font-size: 18px;
        cursor: pointer;
        position: relative
    }

    .pad-left .left .payment p {
        font-family: PingFangSC-Regular;
        font-size: 11px;
        color: #fff;
        letter-spacing: .25px;
        background: #fa6240;
        border-radius: 2px;
        position: absolute;
        right: -16px;
        top: -10px;
        padding: 0 4px
    }

    .pad-left .left .payment .icon {
        width: 18px;
        height: auto;
        position: absolute;
        right: -9px;
        bottom: -1px
    }

    .pad-left .left .payment img {
        width: 26px;
        height: 26px;
        margin-right: 8px
    }

    .pad-left .left .payment:last-child {
        margin-right: 0
    }

    .pad-left .left .bor {
        border: 1px solid #f5a623
    }

    .pay {
        float: right;
        display: -ms-flexbox;
        display: flex;
        -ms-flex-align: center;
        align-items: center;
        margin-right: 45px
    }

    .bot-font-small {
        margin-right: 15px
    }

    .true-price {
        font-size: 36px;
        color: #333
    }

    .go-buy-btn {
        width: 110px;
        height: 38px;
        outline: none;
        border: none;
        color: #fff;
        line-height: 38px;
        background: #ffc210;
        border-radius: 4px;
        font-family: PingFangSC-Medium;
        font-size: 16px;
        cursor: pointer;
    }

    .coupon-list li {
        display: flex;
        padding-bottom: 10px;
        border-bottom: 1px solid #ddd;
    }

    .coupon-list li:first-child {
        margin-top: 10px;
    }

    .coupon-list li:last-child {
        border-bottom: none;
    }

    .coupon-list li > input + label {
        display: block;
        width: 16px;
        height: 16px;
        cursor: pointer;
        border: 1px solid #9b9b9b;
        background: transparent;
        margin-bottom: 0;
        display: -ms-flexbox;
        display: -webkit-box;
        display: flex;
        -ms-flex-align: center;
        -webkit-box-align: center;
        align-items: center;
        -ms-flex-pack: center;
        -webkit-box-pack: center;
        justify-content: center;
        margin-right: 8px;
    }

    .coupon-list li > input:checked + label {
        background: #ffc210;
        border: none;
    }

    .g-coupon-option {
        font-size: 16px;
        color: #666;
        line-height: 18px;
        width: 150px;
        height: 42px;
        padding-left: 16px;
        border: 1px solid #d9d9d9;
        border-radius: 4px;
        margin-top: 30px;
    }
</style>
