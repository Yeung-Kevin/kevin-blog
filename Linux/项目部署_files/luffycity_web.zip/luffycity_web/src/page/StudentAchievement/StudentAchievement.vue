<template>
    <div>学员成果</div>
</template>

<script>
    export default {
        name: "StudentAchievement"
    }
</script>

<style scoped>

</style>
