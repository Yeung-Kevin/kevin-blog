<template>
    <div class="box">
        <img alt="" class="bac" src="./img/signin.png">
        <div class="box-contain">
            <h1>帮助有志向的年轻人通过努力学习获得体面的工作和生活</h1>
            <div class="contain-main">
                <div class="contain-left">
                    <a class="gohome" href="/home">
                        <img src="./img/logo.png">
                    </a>
                    <section>
                        <div class="section_left">
                            <img alt="" src="//hcdn1.luffycity.com/static/frontend/degreecourse/1/xue_1561114268.1875634.svg">
                        </div>
                        <div class="section_right">
                            <p>学</p>
                            <span>名师前沿精品课程</span>
                        </div>
                    </section>
                    <section>
                        <div class="section_left">
                            <img alt="" src="//hcdn1.luffycity.com/static/frontend/degreecourse/1/lian_1561114268.0269804.svg">
                        </div>
                        <div class="section_right">
                            <p>练</p>
                            <span>章节作业 + 阶段测试</span>
                        </div>
                    </section>
                    <section>
                        <div class="section_left">
                            <img alt="" src="//hcdn1.luffycity.com/static/frontend/degreecourse/1/gai_1561114267.9632323.svg">
                        </div>
                        <div class="section_right">
                            <p>改</p>
                            <span>逐行代码批改</span>
                        </div>
                    </section>
                    <section>
                        <div class="section_left">
                            <img alt="" src="//hcdn1.luffycity.com/static/frontend/degreecourse/1/guan_1561114267.842958.svg">
                        </div>
                        <div class="section_right">
                            <p>管</p>
                            <span>1V1导师 + 班主任督学</span>
                        </div>
                    </section>
                    <section>
                        <div class="section_left">
                            <img alt="" src="//hcdn1.luffycity.com/static/frontend/degreecourse/1/ce_1561114266.127703.svg">
                        </div>
                        <div class="section_right">
                            <p>测</p>
                            <span>1V1考核 + 阶段测试</span>
                        </div>
                    </section>
                </div>
                <div class="contain-right">
                    <ul>
                        <li class="item_active">密码登录</li>
                        <!--<li>短信登录</li>-->
                    </ul>
                    <hr>
                    <div class="username inputcontain">
                        <a>
                            <img alt="" src="//hcdn1.luffycity.com/static/frontend/index/shouji@1x_1560849098.2282765.svg">
                        </a>
                        <input placeholder="用户名/手机号" maxlength="20" autofocus="autofocus" v-model="username">
                    </div>
                    <div class="password inputcontain">
                        <a>
                            <img alt="" src="//hcdn1.luffycity.com/static/frontend/index/mima-4@1x_1560849097.9023619.svg">
                        </a>
                        <input id="passwordinput" placeholder="密码" maxlength="20" type="password" v-model="password">
                        <a class="eye" style="display: none;">
                            <img alt="" src="//hcdn1.luffycity.com/static/frontend/index/yanjing@1x_1560849097.8918953.svg"></a>
                        <a class="eye">
                            <img alt="" src="//hcdn1.luffycity.com/static/frontend/index/眼睛关闭@1x_1560849097.5098064.svg">
                        </a>
                    </div>
                    <button id="confirmbtn" @click="login">确定</button>
                    <div class="otherway">
                        <div class="oauth-box">
                            <div class="oauth-bg">
                                <img alt="" src="//hcdn1.luffycity.com/static/frontend/degreecourse/1/dengluweixin_1561115209.1755617.svg">
                                <span>微信登录</span>
                            </div>
                        </div>
                        <div>
                            <span>没有账号，</span>
                            <span class="link-btn">立即注册</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    import {reqLogin} from '../../api'
    import {RECEIVE_TOKEN} from '../../store/mutations-types'

    export default {
        name: "Signin",
        data() {
            return {
                username: '',
                password: ''
            }
        },
        methods: {
            async login() {
                const {username, password} = this;
                let res = await reqLogin({username, password});
                if (res.code) {
                    this.$store.commit(RECEIVE_TOKEN, {token: res.token, username: this.username});

                    let url = this.$route.query.backUrl;
                    if (url) {
                        this.$router.push({path: url})
                    } else {
                        this.$router.push({name: 'home'})
                    }


                } else {
                    alert('登陆失败')
                }
            }

        },
        mounted() {

        }
    }
</script>

<style scoped>
    .box {
        width: 100%;
        position: absolute;
        top: 0;
        bottom: 0;
        margin-top: -120px;
        display: -ms-flexbox;
        display: flex;
        -ms-flex-direction: column;
        flex-direction: column;
        -ms-flex-align: center;
        align-items: center
    }

    .box input, .box button {
        outline: none;
    }

    .box .bac {
        position: absolute;
        top: 0;
        bottom: 0;
        width: 100%;
        height: 100%;
    }

    .box .box-contain {
        position: absolute;
        left: 50%;
        top: 280px;
        transform: translateX(-50%);
        width: 792px;
        text-align: center
    }

    .box .box-contain h1 {
        font-size: 20px;
        font-weight: 500;
        color: #282828;
        margin-bottom: 30px
    }

    .box .box-contain .contain-main {
        width: 792px;
        height: 514px;
        box-shadow: 0 0 10px 0 #e9e9e9;
        display: -ms-flexbox;
        display: flex
    }

    .box .box-contain .contain-main .contain-left {
        width: 252px;
        background: #eef8ff;
        height: 100%;
        padding-left: 38px;
        text-align: left
    }

    .box .box-contain .contain-main .contain-left .gohome {
        cursor: pointer
    }

    .box .box-contain .contain-main .contain-left a {
        width: 120px;
        display: inline-block;
        margin-top: 20px;
        margin-bottom: 30px
    }

    .box .box-contain .contain-main .contain-left a img {
        width: 100%
    }

    .box .box-contain .contain-main .contain-left section {
        display: -ms-flexbox;
        display: flex;
        -ms-flex-align: center;
        align-items: center
    }

    .box .box-contain .contain-main .contain-left section .section_left {
        width: 24px;
        -ms-flex-align: center;
        align-items: center
    }

    .box .box-contain .contain-main .contain-left section .section_left img {
        width: 100%
    }

    .box .box-contain .contain-main .contain-left section .section_right {
        margin-left: 30px;
        margin-bottom: 18px
    }

    .box .box-contain .contain-main .contain-left section .section_right p {
        font-size: 18px;
        font-weight: 500;
        color: #444;
        margin-bottom: 16px
    }

    .box .box-contain .contain-main .contain-left section .section_right span {
        font-size: 14px;
        font-weight: 400;
        color: #999
    }

    .box .box-contain .contain-main .contain-right {
        margin-left: 105px
    }

    .box .box-contain .contain-main .contain-right .err {
        bottom: -20px;
        text-align: left
    }

    .box .box-contain .contain-main .contain-right .err1, .box .box-contain .contain-main .contain-right .err {
        color: red !important;
        font-size: 12px !important;
        padding: 0 !important;
        display: block;
        text-decoration: none;
        position: absolute;
        left: 6px;
        width: 100% !important
    }

    .box .box-contain .contain-main .contain-right .err1 {
        bottom: -16px
    }

    .box .box-contain .contain-main .contain-right .nationcode {
        position: absolute;
        top: -36px;
        left: 0;
        width: 210px;
        background: #fff;
        border: 1px solid #ddd;
        color: #999;
        max-height: 280px;
        overflow: scroll;
        z-index: 6;
        display: block !important
    }

    .box .box-contain .contain-main .contain-right .nationcode li {
        text-align: left;
        width: 100%;
        height: 30px;
        cursor: pointer;
        line-height: 30px;
        font-size: 14px;
        margin-left: 10px
    }

    .box .box-contain .contain-main .contain-right .getfocus {
        border: 1px solid #282828 !important
    }

    .box .box-contain .contain-main .contain-right button {
        width: 330px;
        height: 40px;
        background: #050505;
        font-size: 16px;
        font-weight: 500;
        color: #fff;
        letter-spacing: 4px;
        margin-top: 46px;
        cursor: pointer;
    }

    .box .box-contain .contain-main .contain-right .link-btn {
        color: #ffc220 !important;
        cursor: pointer
    }

    .box .box-contain .contain-main .contain-right .otherway {
        display: -ms-flexbox;
        display: flex;
        -ms-flex-pack: justify;
        justify-content: space-between;
        margin-top: 12px
    }

    .box .box-contain .contain-main .contain-right .otherway span {
        font-size: 14px;
        font-weight: 500;
        color: #aaa
    }

    .box .box-contain .contain-main .contain-right ul {
        width: 330px;
        display: -ms-flexbox;
        display: flex;
        margin-top: 80px
    }

    .box .box-contain .contain-main .contain-right ul li {
        font-size: 18px;
        font-weight: 500;
        color: #999;
        margin-right: 50px;
        cursor: pointer;
        padding-bottom: 20px
    }

    .box .box-contain .contain-main .contain-right ul .item_active {
        color: #282828 !important;
        border-bottom: 3px solid #282828;
        margin-bottom: -4px
    }

    .box .box-contain .contain-main .contain-right hr {
        padding: 0;
        margin: 2px auto;
        height: 1px;
        border: none;
        border-top: 1px solid #ddd
    }

    .box .box-contain .contain-main .contain-right .username {
        border: 1px solid #ddd;
        padding-left: 15px;
        display: -ms-flexbox;
        display: flex;
        -ms-flex-align: center;
        align-items: center;
        margin-top: 40px;
        position: relative
    }

    .box .box-contain .contain-main .contain-right .username a {
        display: inline-block;
        width: 14px
    }

    .box .box-contain .contain-main .contain-right .username a img {
        width: 100%
    }

    .box .box-contain .contain-main .contain-right .username input {
        width: 200px;
        margin: 3px 12px;
        font-size: 14px;
        color: #282828;
        height: 34px;
        border: none;
    }

    .box .box-contain .contain-main .contain-right .phone {
        border: 1px solid #ddd;
        padding-left: 15px;
        display: -ms-flexbox;
        display: flex;
        -ms-flex-align: center;
        align-items: center;
        margin-top: 40px;
        position: relative
    }

    .box .box-contain .contain-main .contain-right .phone span {
        font-size: 16px;
        font-weight: 400;
        color: #282828;
        padding-left: 11px;
        padding-right: 6px;
        cursor: pointer
    }

    .box .box-contain .contain-main .contain-right .phone a {
        display: inline-block;
        width: 14px;
        cursor: pointer
    }

    .box .box-contain .contain-main .contain-right .phone a img {
        width: 100%
    }

    .box .box-contain .contain-main .contain-right .phone input {
        width: 200px;
        margin: 3px 12px;
        font-size: 14px;
        color: #282828;
        height: 34px;
        border: none
    }

    .box .box-contain .contain-main .contain-right .password {
        border: 1px solid #ddd;
        padding-left: 15px;
        display: -ms-flexbox;
        display: flex;
        -ms-flex-align: center;
        align-items: center;
        margin-top: 40px;
        position: relative
    }

    .box .box-contain .contain-main .contain-right .password a {
        display: inline-block;
        width: 14px
    }

    .box .box-contain .contain-main .contain-right .password a img {
        width: 100%
    }

    .box .box-contain .contain-main .contain-right .password input {
        width: 224px;
        margin: 3px 12px;
        font-size: 14px;
        color: #282828;
        height: 34px;
        border: none
    }

    .box .box-contain .contain-main .contain-right .password .eye {
        width: 18px !important;
        display: inline-block;
        float: right !important;
        margin-left: 12px;
        cursor: pointer
    }

    .box .box-contain .contain-main .contain-right .password .eye img {
        width: 100% !important
    }

    .box .box-contain .contain-main .contain-right .checkword {
        border: 1px solid #ddd;
        padding-left: 15px;
        display: -ms-flexbox;
        display: flex;
        -ms-flex-align: center;
        align-items: center;
        margin-top: 40px;
        position: relative
    }

    .box .box-contain .contain-main .contain-right .checkword a {
        display: inline-block;
        width: 14px
    }

    .box .box-contain .contain-main .contain-right .checkword a img {
        width: 100%
    }

    .box .box-contain .contain-main .contain-right .checkword input {
        width: 172px;
        margin: 3px 12px;
        font-size: 14px;
        color: #282828;
        height: 34px;
        border: none
    }

    .box .box-contain .contain-main .contain-right .checkword span {
        font-size: 14px;
        font-weight: 500;
        color: #d8d8d8
    }

    .box .box-contain .contain-main .contain-right .checkword .inline {
        padding-right: 14px !important
    }
</style>
