<template>
    <div class="information order-info-wrap">
        <div>
            <ul class="table-head">
                <li class="order-info" style="width: 325px; margin-left: 20px;margin-right: 28px">订单</li>
                <li class="buyer-limit-date">有效期</li>
                <li class="per-price" style="width: 130px">课程价格</li>
                <li class="course-discount">抵扣</li>
                <li class="course-discount">实付金额</li>
                <li class="course-discount">交易状态</li>
                <li class="handle">交易操作</li>
            </ul>
            <p class="loading-box"></p>

            <div class="table-main" v-for="(v, i) in order_list" :key="i">
                <div class="table-order-ceil">
                    <span class="my-order-num my-order-time">{{ v.date }}</span>
                    <span class="my-order-num my-order-code">订单号：<span class="my-order-number">{{ v.order_number }}</span></span>
                </div>
                <div style="height: 100%;display: flex; align-item: center">
                    <div class="left-wrap" style="border-right: 1px solid #E9E9E9; border-bottom: 1px solid #E9E9E9; border-left: 1px solid #E9E9E9"> <!--v-for-start-->
                        <ul v-for="(c, j) in v.course" :key="j" class="order-info course-inf" style="display: flex; align-items: center;padding: 20px 0 20px 20px">
                            <li class="order-course-detail"><img alt="" style="width: 100px; height: 75px; overflow: hidden" :src="c.course_img">
                                <div>
                                    <p class="my-order-course-tit">{{ c.course_name }}</p>
                                    <!--<p class="activity_name">限时折扣</p>-->
                                </div>
                            </li>
                            <li class="buyer-limit-date buyer-limit-date-font">永久有效</li>
                            <li class="per-price">
                                <span class="original" v-if="c.original_price !== c.price">{{ c.original_price }}</span>
                                <span>{{ c.price }}</span>
                            </li>
                        </ul>
                    </div>
                    <ul class="right-wrap-order">
                        <li class="course-discount" style="text-align: center;height: 100%; display: flex;flex-direction: column;align-items: center; border-right: 1px solid #E9E9E9;font-size: 14px">
                            <span> {{ v.deductible_amount }} </span>
                        </li>
                        <li class="course-discount" style="height: 100%; display: flex; align-items: center; justify-content: center; border-right: 1px solid #E9E9E9">{{ v.actual_amount }}</li>
                        <li class="course-discount" style="height: 100%; display: flex; align-items: center; justify-content: center; border-right: 1px solid #E9E9E9">{{ v.status_txt }}</li>
                        <li class="handle">
                            <button class="charge-btn" style="display: none;"></button>
                            <button class="charge-btn" style="display: none;">去学习</button>
                            <p class="evaluation" style="display: none;">评价</p></li>
                    </ul>
                </div>
            </div><!--v-for-end--> </div>
    </div>
</template>

<script>
    import {reqMyOrder} from '../../api'

    export default {
        name: "MyOrder",
        data() {
            return {
                order_list: []
            }
        },
        methods: {
            async get_order_list() {
                const res = await reqMyOrder();
                this.order_list = res.data;
                console.log(res.data)
            }
        },
        mounted() {
            this.get_order_list()
        }
    }
</script>

<style scoped>
    .loading-box {
        width: 100%;
        display: -ms-flexbox;
        display: flex;
        -ms-flex-pack: distribute;
        justify-content: space-around;
        margin-top: 20px
    }

    .loading-box .loading {
        width: 25px;
        height: 25px
    }

    .activity_name {
        font-size: 12px;
        color: #fa6240;
        padding: 0 5px;
        border: 1px solid #fa6240;
        border-radius: 4px;
        margin-top: 4px;
        position: absolute
    }

    .wrapper {
        width: 1200px;
        height: auto;
        margin: 0 auto
    }

    .my-item-wrap {
        width: 474px;
        height: 31px;
        margin: 41px auto 0;
        display: -ms-flexbox;
        display: flex;
        -ms-flex-pack: justify;
        justify-content: space-between;
        cursor: pointer
    }

    .my-active {
        border-bottom: 1px solid #000
    }

    .information {
        margin-bottom: 63px
    }

    .order-info-wrap {
        width: 1200px;
        padding-top: 30px;
        border-top: 1px solid #e8e8e8;
        margin: 0 auto;
    }

    .table-head {
        width: 100%;
        height: 60px;
        background: #e9e9e9;
        display: -ms-flexbox;
        display: flex;
        -ms-flex-align: center;
        align-items: center
    }

    .table-head > li {
        height: 60px;
        line-height: 60px;
        list-style: none;
        font-family: PingFangSC-Medium;
        font-size: 13px;
        color: #333
    }

    .table-main {
        width: 100%;
        margin-bottom: 20px
    }

    .table-order-ceil {
        display: -ms-flexbox;
        display: flex;
        height: 44px;
        color: #4a4a4a;
        font-size: 14px;
        background: #f3f3f3;
        -ms-flex-align: center;
        align-items: center;
        font-family: PingFangSC-Regular
    }

    .order-tr-style {
        border: 1px solid #e9e9e9
    }

    .order-info {
        border-bottom: 1px solid #e9e9e9
    }

    .order-info:last-child {
        border-bottom: none
    }

    .order-course-detail {
        display: -ms-flexbox;
        display: flex;
        -ms-flex-align: center;
        align-items: center;
        margin-right: 28px
    }

    .order-course-detail img {
        margin-right: 22px
    }

    .buyer-limit-date {
        width: 60px;
        text-align: center
    }

    .discount {
        width: 80px;
        text-align: center
    }

    .buyer-limit-date-font {
        font-size: 12px;
        color: #ff5502;
        font-family: PingFangSC-Medium
    }

    .per-price {
        width: 124px;
        text-align: center;
        font-size: 14px;
        color: #666;
        font-family: PingFangSC-Medium
    }

    .per-price .original {
        display: block;
        color: #d0d0d0;
        font-size: 14px;
        text-decoration: line-through
    }

    .course-discount {
        width: 160px;
        text-align: center;
        -ms-flex-pack: center;
        justify-content: center;
        font-family: PingFangSC-Medium;
        font-size: 14px;
        color: #666
    }

    .handle {
        width: 160px;
        text-align: center
    }

    .handle .evaluation {
        color: #4a90e2;
        font-size: 14px;
        text-align: center;
        margin-top: 10px;
        cursor: pointer;
        font-family: PingFangSC-Medium
    }

    .td-border {
        display: -ms-flexbox;
        display: flex;
        -ms-flex-align: center;
        align-items: center;
        -ms-flex-pack: center;
        justify-content: center;
        border-left: 1px solid #e8e8e8
    }

    .my-order-num {
        font-size: 12px;
        display: inline-block
    }

    .my-order-time {
        margin-left: 20px
    }

    .my-order-code {
        margin-left: 29px
    }

    .my-order-type {
        margin-left: 22px
    }

    .my-order-course-tit {
        width: 203px;
        font-size: 13px;
        color: #333;
        line-height: 20px;
        font-family: PingFangSC-Medium
    }

    .cancel-order-btn {
        display: block;
        border: none;
        outline: none;
        background: none;
        margin-top: 18px;
        font-size: 14px;
        color: #9b9b9b;
        width: 102px;
        text-align: center
    }

    .charge-btn {
        width: 100px;
        height: 32px;
        font-size: 14px;
        color: #fff;
        background: #ffc210;
        border-radius: 4px;
        border: none;
        outline: none;
        font-family: PingFangSC-Medium;
        transition: all .25s ease
    }

    .right-wrap-order {
        height: auto;
        margin: 0;
        border-right: 1px solid #e9e9e9;
        border-bottom: 1px solid #e9e9e9
    }

    .right-wrap-order, .wx-pay {
        display: -ms-flexbox;
        display: flex;
        -ms-flex-align: center;
        align-items: center
    }

    .wx-pay {
        width: 100%;
        height: 100%;
        position: fixed;
        left: 0;
        top: 0;
        background: rgba(0, 0, 0, .5);
        z-index: 101;
        -ms-flex-pack: center;
        justify-content: center
    }

    .wx-pay .mask {
        padding: 36px 54px;
        text-align: center;
        background: #fff;
        font-family: PingFangSC-Regular;
        animation: x0ppop .45s ease
    }

    .wx-pay .mask p:first-of-type {
        font-size: 20.65px;
        color: #4a4a4a
    }

    .wx-pay .mask p:first-of-type i {
        font-style: normal
    }

    .wx-pay .mask .code {
        width: 212px;
        height: 190px;
        margin-top: 20px;
        margin-bottom: 10px
    }

    .wx-pay .mask span {
        display: block;
        font-size: 15px;
        color: #9b9b9b;
        letter-spacing: .25px;
        margin-bottom: 20px
    }

    .wx-pay .mask p:nth-of-type(2) {
        font-size: 18px;
        color: #5e5e5e;
        letter-spacing: .29px;
        cursor: pointer
    }

    .wx-pay .mask p:nth-of-type(2) img {
        margin-right: 7px
    }

    @keyframes x0ppop {
        0% {
            transform: scale(.9);
            opacity: .3
        }
        50% {
            transform: scale(1.1);
            opacity: .7
        }
        to {
            transform: scale(1);
            opacity: 1
        }
    }
</style>
