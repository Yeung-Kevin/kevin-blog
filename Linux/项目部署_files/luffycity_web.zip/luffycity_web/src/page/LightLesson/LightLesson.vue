<template>
    <div>
        <p>轻课只有登陆的才能访问该网址，和该网址的相关接口</p>
        <p>{{msg}}</p>
    </div>
</template>

<script>
    import {light_course} from '../../api'

    export default {
        name: "LightLesson",
        data() {
            return {
                msg: ''
            }
        },
        async mounted() {
            let ret = await light_course();
            console.log(ret)
            this.msg = ret.msg;
        }
    }
</script>

<style scoped>

</style>
