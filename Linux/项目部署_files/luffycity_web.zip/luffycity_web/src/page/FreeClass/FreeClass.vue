<template>
    <!--<div>
        <ul>
            <li v-for="(value,index) in course_list" :key="index" style="margin-top: 10px;">
                <router-link :to="{name:'free_class_detail', params: { id: value.id }}">{{value.title}}</router-link>
            </li>
        </ul>
    </div>-->
    <div class="course" style="min-height: 370px;">
        <main>
            <div class="screening">
                <ul class="ul1">
                    <p>课程分类:</p>
                    <li class="this1">全部</li>
                    <li>Python</li>
                    <li>Linux运维</li>
                    <li>前端开发</li>
                    <li>Python进阶</li>
                    <li>开发工具</li>
                    <li>Go语言</li>
                    <li>机器学习</li>
                    <li>技术生涯</li>
                    <li>数据分析</li>
                    <li>web安全</li>
                </ul>
                <div class="ul2">
                    <ul><p>筛&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;选:</p>
                        <li class="this">默认</li>
                        <li>人气</li>
                        <li class="price">价格</li>
                    </ul>
                    <p class="all">共24个课程</p></div>
            </div>
            <div class="course-list">
                <!-- 实例 -->
                <dl>
                    <dt><img alt=" " src="//hcdn1.luffycity.com/static/frontend/degreecourse/16/PC列表页@3x_1562842317.3393981.png"></dt>
                    <dd>
                        <div class="name"><p>K8S 集群实战</p>
                            <p><img src="/static/img/course-num.6fe496c.svg" alt=""> 482人已加入学习</p></div>
                        <div class="teacher"><p>周玉强 路飞高级讲师</p>
                            <p>共33课时<span>/已更新32课时</span></p></div>
                        <ul> <!--v-for-start-->
                            <li key="0"><img src="/static/img/course-video1.311759a.svg" alt="" class="img1"> <img src="/static/img/course-video2.ffb09f6.svg" alt="" class="img2">
                                <p>01 | k8s的应用场景</p> <span>免费</span><!--v-if--> </li>
                            <li key="1"><img src="/static/img/course-video1.311759a.svg" alt="" class="img1"> <img src="/static/img/course-video2.ffb09f6.svg" alt="" class="img2">
                                <p>02 | k8s的核心组件和架构</p> <span>免费</span><!--v-if--> </li>
                            <li key="2"><img src="/static/img/course-video1.311759a.svg" alt="" class="img1"> <img src="/static/img/course-video2.ffb09f6.svg" alt="" class="img2">
                                <p>03 | 视频导读v3</p> <span>免费</span><!--v-if--> </li>
                            <li key="3"><img src="/static/img/course-video1.311759a.svg" alt="" class="img1"> <img src="/static/img/course-video2.ffb09f6.svg" alt="" class="img2">
                                <p>04 | 什么是k8sv1</p> <span>免费</span><!--v-if--> </li><!--v-for-end--> </ul>
                        <div class="price"><p><span class="discount">限时折扣</span><!--v-if--> <span class="present-price">￥78.97元</span><!--v-if--> <span class="original-price">原价：149.00元</span><!--v-if--> <!--v-if--> </p>
                            <button>立即购买</button>
                        </div><!--v-if--> </dd>
                </dl>
                <!-- 真实数据 -->
                <dl v-for="(value, index) in course_list" :key="index" @click="jump_link(value.id)">
                    <dt><img alt="" :src="value.course_img"></dt>
                    <dd>
                        <div class="name"><p>{{ value.name }}</p>
                            <p><i class="fa fa-user-o" style="margin:3px 5px 0 0"></i> 482人已加入学习</p></div>
                        <div class="teacher"><p>周玉强 路飞高级讲师</p>
                            <p>共33课时<span>/已更新32课时</span></p></div>
                        <ul> <!--v-for-start-->
                            <li key="0">
                                <i class="fa fa-play-circle-o" style="margin:3px 5px 0 0"></i>
                                <p>01 | k8s的应用场景</p> <span>免费</span><!--v-if--> </li>
                            <li key="1">
                                <i class="fa fa-play-circle-o" style="margin:3px 5px 0 0"></i>
                                <p>02 | k8s的核心组件和架构</p> <span>免费</span><!--v-if--> </li>
                            <li key="2">
                                <i class="fa fa-play-circle-o" style="margin:3px 5px 0 0"></i>
                                <p>03 | 视频导读v3</p> <span>免费</span><!--v-if--> </li>
                            <li key="3">
                                <i class="fa fa-play-circle-o" style="margin:3px 5px 0 0"></i>
                                <p>04 | 什么是k8sv1</p> <span>免费</span><!--v-if--> </li><!--v-for-end--> </ul>
                        <div class="price"><p><span class="discount">限时折扣</span><!--v-if--> <span class="present-price">￥78.97元</span><!--v-if--> <span class="original-price">原价：149.00元</span><!--v-if--> <!--v-if--> </p>
                            <button>立即购买</button>
                        </div><!--v-if--> </dd>
                </dl>
            </div>
        </main>
    </div>
</template>

<script>
    import {reqCourse} from "@/api";

    export default {
        name: "FreeClass",
        data() {
            return {
                course_list: []
            }
        },
        methods: {
            jump_link(id) {
                this.$router.push({name: 'free_class_detail', params: {id}})
            }
        },
        async mounted() {
            const course_obj = await reqCourse();
            console.log(course_obj.data);
            this.course_list = course_obj.data
        }
    }
</script>

<style scoped>
    .course {
        -ms-flex: 1;
        flex: 1;
        width: 100%;
        height: 100%;
        background: #f6f6f6;
        display: -ms-flexbox;
        display: flex;
        -ms-flex-align: start;
        align-items: flex-start
    }

    .course .loading {
        width: 100%;
        height: auto;
        text-align: center;
        position: relative;
        z-index: 1
    }

    .course .loading img {
        width: 24px;
        height: 24px;
        position: absolute;
        top: 80px;
        transition: all .3s ease
    }

    .course main {
        width: 1100px;
        height: auto;
        margin: 0 auto;
        padding-top: 35px
    }

    .course main .screening {
        width: 100%;
        height: auto;
        margin-bottom: 35px;
        padding: 25px 30px 25px 20px;
        background: #fff;
        border-radius: 4px;
        box-shadow: 0 2px 4px 0 #f0f0f0
    }

    .course main .screening ul {
        display: -ms-flexbox;
        display: flex;
        -ms-flex-align: center;
        align-items: center;
        font-size: 16px;
        color: #888;
        font-family: PingFangSC-Regular;
        letter-spacing: .36px;
        -ms-flex-wrap: wrap;
        flex-wrap: wrap
    }

    .course main .screening ul li {
        padding: 6px 15px;
        line-height: 16px;
        margin-left: 14px;
        position: relative;
        transition: all .3s ease;
        cursor: pointer;
        color: #4a4a4a
    }

    .course main .screening ul li:nth-child(10) {
        margin-left: 162px
    }

    .course main .screening ul .price:after {
        content: "";
        width: 0;
        border: 5px solid transparent;
        border-bottom-color: #d8d8d8;
        position: absolute;
        right: 0;
        top: 2.5px
    }

    .course main .screening ul .price:before {
        content: "";
        width: 0;
        border: 5px solid transparent;
        border-top-color: #d8d8d8;
        position: absolute;
        right: 0;
        bottom: 2.5px
    }

    .course main .screening ul .change1:after {
        content: "";
        width: 0;
        border: 5px solid transparent;
        border-bottom-color: #ffc210;
        position: absolute;
        right: 0;
        top: 2.5px
    }

    .course main .screening ul .change1:before {
        content: "";
        width: 0;
        border: 5px solid transparent;
        border-top-color: #d8d8d8;
        position: absolute;
        right: 0;
        bottom: 2.5px
    }

    .course main .screening ul .change2:after {
        content: "";
        width: 0;
        border: 5px solid transparent;
        border-bottom-color: #d8d8d8;
        position: absolute;
        right: 0;
        top: 2.5px
    }

    .course main .screening ul .change2:before {
        content: "";
        width: 0;
        border: 5px solid transparent;
        border-top-color: #ffc210;
        position: absolute;
        right: 0;
        bottom: 2.5px
    }

    .course main .screening ul .this {
        color: #ffc210
    }

    .course main .screening ul .this1 {
        color: #ffc210;
        border: 1px solid #ffc210 !important;
        border-radius: 30px
    }

    .course main .screening .ul1:first-child {
        border-bottom: 1px solid #333;
        border-bottom-color: rgba(51, 51, 51, .05);
        padding-bottom: 18px;
        margin-bottom: 17px
    }

    .course main .screening .ul1:first-child li {
        border: 1px solid transparent
    }

    .course main .screening .ul2 {
        display: -ms-flexbox;
        display: flex;
        -ms-flex-align: center;
        align-items: center;
        -ms-flex-pack: justify;
        justify-content: space-between
    }

    .course main .screening .ul2 .all {
        font-family: PingFangSC-Light;
        font-size: 14px;
        color: #9b9b9b
    }

    .course main .course-list {
        width: 100%
    }

    .course main .course-list dl {
        width: 100%;
        height: auto;
        background: #fff;
        padding: 20px 30px 20px 20px;
        display: -ms-flexbox;
        display: flex;
        margin-bottom: 35px;
        border-radius: 2px;
        cursor: pointer;
        box-shadow: 2px 3px 16px rgba(0, 0, 0, .1);
        transition: all .2s ease;
        position: relative
    }

    .course main .course-list dl dt {
        width: 423px;
        height: 210px;
        margin-right: 30px
    }

    .course main .course-list dl dt img {
        width: 100%;
        height: 100%
    }

    .course main .course-list dl dd {
        -ms-flex: 1;
        flex: 1;
        font-family: PingFangSC-Regular;
        line-height: 1.5;
    }

    .course main .course-list dl dd .name {
        display: -ms-flexbox;
        display: flex;
        -ms-flex-align: end;
        align-items: flex-end;
        -ms-flex-pack: justify;
        justify-content: space-between;
        margin-bottom: 8px
    }

    .course main .course-list dl dd .name p {
        display: -ms-flexbox;
        display: flex
    }

    .course main .course-list dl dd .name p img {
        width: 11px;
        height: auto;
        margin-right: 7px
    }

    .course main .course-list dl dd .name p:first-child {
        font-size: 26px;
        color: #333
    }

    .course main .course-list dl dd .name p:last-child {
        font-size: 14px;
        color: #9b9b9b;
        font-family: PingFangSC-Light
    }

    .course main .course-list dl dd .teacher {
        display: -ms-flexbox;
        display: flex;
        -ms-flex-align: end;
        align-items: flex-end;
        -ms-flex-pack: justify;
        justify-content: space-between;
        font-size: 14px;
        color: #9b9b9b;
        margin-bottom: 14px;
        padding-bottom: 14px;
        font-family: PingFangSC-Light;
        border-bottom: 1px solid #333;
        border-bottom-color: rgba(51, 51, 51, .05)
    }

    .course main .course-list dl dd ul {
        display: -ms-flexbox;
        display: flex;
        -ms-flex-wrap: wrap;
        flex-wrap: wrap;
        -ms-flex-align: center;
        align-items: center;
        -ms-flex-pack: justify;
        justify-content: space-between
    }

    .course main .course-list dl dd ul li {
        width: 49%;
        display: -ms-flexbox;
        display: flex;
        -ms-flex-align: center;
        align-items: center;
        font-size: 14px;
        color: #666;
        margin-bottom: 15px;
        cursor: pointer
    }

    .course main .course-list dl dd ul li img {
        width: 16px;
        height: 16px;
        margin-right: 6px
    }

    .course main .course-list dl dd ul li .img2 {
        display: none
    }

    .course main .course-list dl dd ul li span {
        width: 34px;
        height: 20px;
        color: #fd7b4d;
        margin-left: 10px;
        border: 1px solid #fd7b4d;
        border-radius: 2px;
        text-align: center;
        font-size: 13px;
        white-space: nowrap
    }

    .course main .course-list dl dd ul li p {
        max-width: 227px;
        text-overflow: ellipsis;
        overflow: hidden;
        white-space: nowrap;
        font-family: PingFangSC-Regular
    }

    .course main .course-list dl dd ul li:hover {
        color: #ffc210
    }

    .course main .course-list dl dd ul li:hover span {
        color: #ffc210;
        border: 1px solid #ffc210
    }

    .course main .course-list dl dd ul li:hover .img2 {
        display: block
    }

    .course main .course-list dl dd ul li:hover .img1 {
        display: none
    }

    .course main .course-list dl dd .price {
        -ms-flex-pack: justify;
        justify-content: space-between;
        font-family: PingFangSC-Medium;
        margin-top: 7px
    }

    .course main .course-list dl dd .price, .course main .course-list dl dd .price p:first-child {
        display: -ms-flexbox;
        display: flex;
        -ms-flex-align: center;
        align-items: center
    }

    .course main .course-list dl dd .price p:first-child .discount {
        padding: 6px 10px;
        font-size: 16px;
        color: #fff;
        text-align: center;
        margin-right: 8px;
        background: #fa6240;
        border: 1px solid #fa6240;
        border-radius: 10px 0 10px 0;
        font-family: PingFangSC-Regular
    }

    .course main .course-list dl dd .price p:first-child .present-price {
        font-size: 24px;
        color: #fa6240
    }

    .course main .course-list dl dd .price p:first-child .original-price {
        font-family: PingFangSC-Regular;
        text-decoration: line-through;
        font-size: 14px;
        color: #9b9b9b;
        margin-left: 10px
    }

    .course main .course-list dl dd .price button {
        width: 120px;
        height: 38px;
        background: transparent;
        color: #fa6240;
        font-size: 16px;
        border: 1px solid #fd7b4d;
        border-radius: 3px;
        font-family: PingFangSC-Regular;
        transition: all .2s ease-in-out
    }

    .course main .course-list dl dd .price button:hover {
        color: #fff;
        background: #ffc210;
        border: 1px solid #ffc210
    }
</style>
