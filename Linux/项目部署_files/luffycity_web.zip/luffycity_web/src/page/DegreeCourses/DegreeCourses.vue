<template>
    <div>学位课</div>
</template>

<script>
    export default {
        name: "DegreeCourses"
    }
</script>

<style scoped>

</style>
