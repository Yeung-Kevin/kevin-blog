<template>
    <div>题库</div>
</template>

<script>
    export default {
        name: "QuestionBank"
    }
</script>

<style scoped>

</style>
