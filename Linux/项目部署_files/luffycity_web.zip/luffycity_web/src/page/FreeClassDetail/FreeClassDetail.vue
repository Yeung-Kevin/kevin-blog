<template>
    <div class="courseitem">
        <div class="head-wrap">
            <div class="head-video">
                <div class="videos">
                    <img :src="course_detail.img" alt="">
                </div>
                <div class="item"><p class="name">{{ course_detail.name }}</p>
                    <p class="data">3273人在学&nbsp;&nbsp;&nbsp;&nbsp;课程总时长：{{ course_detail.hours }}课时&nbsp;&nbsp;&nbsp;&nbsp;难度：{{ course_detail.level }}</p>
                    <!--<div class="preferential"><p>限时免费</p>
                        <p>距离结束：仅剩 07天 07小时 32分 <span>12</span> 秒</p>
                    </div>-->
                    <p class="price bac">
                        <span>价格</span><span class="sp1">¥{{ price }}</span><!--<span class="sp2">¥9.00</span>-->
                    </p>
                    <div class="price-policy-box">
                        <p class="title">价格策略</p>
                        <ul class="price-policy-list">
                            <li class="price-policy"
                                v-for="(val, index) in course_detail.price_policy"
                                :key="index"
                                @click="change_price_policy(val.price_policy_id, val.price)"
                                :class="{active: price_policy_id === val.price_policy_id}"
                            >
                                <p>期限: {{val.valid_period_txt}}</p>
                                <p>价格: ￥{{val.price}}</p>
                            </li>
                        </ul>
                    </div>
                    <div class="bottom">
                        <p class="btns">
                            <button class="btn1">立即购买</button>
                            <button class="btn2">免费试学</button>
                        </p>
                        <p class="add" @click="add_cart">
                            <img src="./img/course-shop.svg" alt=""> 加入购物车
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    import {reqCourseDetail, reqAddCart} from "../../api";

    export default {
        name: "FreeClassDetail",
        data() {
            return {
                course_detail: {},
                price_policy_id: null,
                price: 0
            }
        },
        watch: {
            // 写法一
            $route(to, from) {
                let id = to.params.id;
                this.get_course(id);
            }
            // 写法二 -> 深度监听
            /*$route: {
                handler: function (val, oldVal) {
                    let id = val.params.id;
                    this.get_course(id);
                },
                // 深度观察监听
                deep: true
            }*/
        },
        methods: {
            async get_course(id) {
                const course_obj = await reqCourseDetail(id);
                this.course_detail = course_obj.data;
                this.price_policy_id = this.course_detail.price_policy[0].price_policy_id;
                this.price = this.course_detail.price_policy[0].price;
                console.log(course_obj.data)
            },
            async add_cart() {
                let data = {
                    course_id: this.course_detail.course_id,
                    price_policy_id: this.price_policy_id,
                };
                const res_obj = await reqAddCart(data);
                console.log(res_obj)
            },
            change_price_policy(id, price) {
                this.price_policy_id = id;
                this.price = price;
            }
        },
        mounted() {
            let id = this.$route.params.id;
            this.get_course(id)
        }
    }
</script>

<style scoped>
    .courseitem {
        width: 100%;
        height: auto;
        background: #fafafa
    }

    .courseitem .head-wrap {
        width: 100%;
        height: auto;
        background: #fff;
        padding-top: 30px
    }

    .courseitem .head-wrap .head-video {
        width: 1200px;
        height: auto;
        display: -ms-flexbox;
        display: flex;
        margin: 0 auto
    }

    .courseitem .head-wrap .head-video .videos {
        width: 690px;
        height: 388px;
        background: #000
    }

    .courseitem .head-wrap .head-video .videos div {
        width: 100%;
        height: 100%
    }

    .courseitem .head-wrap .head-video .videos img {
        width: 100%;
        height: 100%;
    }

    .courseitem .head-wrap .head-video .item {
        -ms-flex: 1;
        flex: 1;
        background: #fff;
        position: relative
    }

    .courseitem .head-wrap .head-video .item .name {
        font-family: PingFangSC-Medium;
        font-size: 20px;
        color: #333;
        padding: 10px 23px;
        letter-spacing: .45px
    }

    .courseitem .head-wrap .head-video .item .data {
        padding-left: 23px;
        padding-right: 23px;
        padding-bottom: 16px;
        font-size: 14px;
        color: #9b9b9b;
        font-family: PingFangSC-Light
    }

    .courseitem .head-wrap .head-video .item .preferential {
        width: 100%;
        height: auto;
        background: #fa6240;
        font-family: PingFangSC-Regular;
        font-size: 14px;
        color: #4a4a4a;
        display: -ms-flexbox;
        display: flex;
        -ms-flex-align: center;
        align-items: center;
        -ms-flex-pack: justify;
        justify-content: space-between;
        padding: 10px 23px
    }

    .courseitem .head-wrap .head-video .item .preferential p:first-of-type {
        font-family: PingFangSC-Medium;
        font-size: 16px;
        color: #fff;
        letter-spacing: .36px
    }

    .courseitem .head-wrap .head-video .item .preferential p:nth-of-type(2) {
        font-family: PingFangSC-Regular;
        font-size: 14px;
        color: #fff
    }

    .courseitem .head-wrap .head-video .item .preferential p:nth-of-type(2) span {
        width: 24px;
        height: auto;
        display: inline-block;
        background: #fafafa;
        color: #5e5e5e;
        padding: 6px 0;
        text-align: center
    }

    .courseitem .head-wrap .head-video .item .price {
        width: 100%;
        height: auto;
        background: #f9f1e7;
        font-family: PingFangSC-Regular;
        font-size: 14px;
        color: #4a4a4a;
        display: -ms-flexbox;
        display: flex;
        -ms-flex-align: end;
        align-items: flex-end;
        padding: 5px 23px
    }

    .courseitem .head-wrap .head-video .item .price .sp1 {
        font-size: 26px;
        color: #fa6240;
        margin-left: 10px;
        display: inline-block;
        margin-bottom: -5px
    }

    .courseitem .head-wrap .head-video .item .price .sp2 {
        font-size: 14px;
        color: #9b9b9b;
        margin-left: 10px;
        text-decoration: line-through
    }

    .courseitem .head-wrap .head-video .item .bac {
        background: #fff
    }

    .courseitem .head-wrap .head-video .item .bottom {
        position: absolute;
        left: 0;
        bottom: 20px;
        width: 100%;
        height: auto;
        -ms-flex-pack: justify;
        justify-content: space-between;
        padding-left: 23px;
        padding-right: 23px
    }

    .courseitem .head-wrap .head-video .item .bottom .btns, .courseitem .head-wrap .head-video .item .bottom {
        display: -ms-flexbox;
        display: flex;
        -ms-flex-align: center;
        align-items: center
    }

    .courseitem .head-wrap .head-video .item .bottom .btns button {
        width: 125px;
        height: 40px;
        background: #ffc210;
        border-radius: 4px;
        color: #fff;
        cursor: pointer;
        margin-right: 15px;
        border: none;
    }

    .courseitem .head-wrap .head-video .item .bottom .btns .btn2 {
        background: #fff;
        color: #ffc210;
        border: 1px solid #ffc210
    }

    .courseitem .head-wrap .head-video .item .bottom .add {
        font-size: 14px;
        color: #ffc210;
        text-align: center;
        display: -ms-flexbox;
        display: flex;
        -ms-flex-align: center;
        align-items: center;
        cursor: pointer;
        font-family: PingFangSC-Regular
    }

    .courseitem .head-wrap .head-video .item .bottom .add img {
        width: 20px;
        height: auto;
        margin-right: 7px
    }

    .price-policy-box {
        padding: 15px 23px;
    }

    .price-policy-box .title {
        float: left;
        margin-top: 0;
        margin-right: 10px;
        font-size: 14px;
        color: #4a4a4a;
    }

    .price-policy-box .price-policy-list {
        display: flex;
        padding: 0;
    }

    .price-policy-box .price-policy {
        list-style: none;
        padding: 10px;
        border: 1px solid #ddd;
        font-size: 14px;
        cursor: pointer;
        margin-right: 10px;
    }

    .price-policy-box .price-policy.active {
        background: #3dc3c3;
        color: #fff;
    }

    .price-policy-box .price-policy p {
        margin: 0;
    }

    .price-policy-box .price-policy p:first-child {
        margin-bottom: 5px;
    }

</style>
