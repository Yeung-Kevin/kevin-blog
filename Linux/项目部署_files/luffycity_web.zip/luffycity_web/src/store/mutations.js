import Vue from 'vue'
import Cookie from 'vue-cookies'

import {
    RECEIVE_TOKEN,
    LOGOUT,
} from './mutations-types'

export default {
    [RECEIVE_TOKEN](state, {token, username}) {
        state.token = token;
        state.username = username;
        Cookie.set("username", username, "20min");
        Cookie.set("token", token, "20min");
    },
    [LOGOUT](state) {
        state.token = '';
        state.username = '';
        Cookie.remove('username');
        Cookie.remove('token');
    }
}
