export const RECEIVE_TOKEN = 'receive_token'; // 接受token
export const LOGOUT = 'logout'; // 登出
