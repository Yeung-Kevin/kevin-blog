import Cookie from 'vue-cookies'

export default {
    token: Cookie.get('token'),
    username: Cookie.get('username'),
}
