import ajax from './ajax'

// 获取课程列表
export const reqCourse = () => ajax('/v1/course/');
// 获取课程详情
export const reqCourseDetail = id => ajax(`/v1/course/${id}/`);
// 登陆
export const reqLogin = data => ajax('/v1/signin/', data, 'POST');
// 轻课（token认证）
export const light_course = () => ajax('/v1/light_course/');
// 添加购物车
export const reqAddCart = data => ajax('/v1/shoppingcart/', data, 'POST');
// 获取购物车
export const reqShoppingCart = () => ajax('/v1/shoppingcart/');
// 修改购物车
export const reqEditCart = data => ajax('/v1/shoppingcart/', data, 'PUT');
// 删除购物车
export const reqDelCart = data => ajax('/v1/shoppingcart/', data, 'DELETE');
// 去结算
export const goSettlement = data => ajax('/v1/buy/', data, 'POST');
// 查看结算课程
export const reqBuy = () => ajax('/v1/buy/');
// 修改结算课程
export const reqEditBuy = data => ajax('/v1/buy/', data, 'PUT');
// 支付
export const pay = data => ajax('/v1/payment/', data, 'POST');
// 我的订单
export const reqMyOrder = () => ajax('/v1/my_order/');
