import axios from 'axios'
import store from '../store'

axios.defaults.baseURL = 'http://127.0.0.1:8000/api';
// axios.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded';

export default function (url, data = {}, type = "GET") {
    return new Promise((resolve, reject) => {
        let promise;

        // 获取token
        const token = store.state.token;
        // 每次请求都携带token
        axios.defaults.headers.common['Authorization'] = token;

        if (type === 'GET') {
            let dataStr = '';
            Object.keys(data).forEach(key => {
                dataStr += key + '=' + data[key] + '&';
            });
            if (dataStr !== '') {
                dataStr.substring(0, dataStr.lastIndexOf('&'));
                url += '?' + dataStr;
            }
            promise = axios.get(url)
        } else {
            let type_lower = type.toLowerCase();
            promise = axios[type_lower](url, data)
        }

        promise.then((response) => {
            resolve(response.data);
        }).catch((error) => {
            resolve(error);
        })
    });
}
