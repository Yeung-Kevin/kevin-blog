import Vue from 'vue'
import Router from 'vue-router'

import Home from '@/page/Home/Home'
import FreeClass from '@/page/FreeClass/FreeClass'
import FreeClassDetail from '@/page/FreeClassDetail/FreeClassDetail'
import LightLesson from '@/page/LightLesson/LightLesson'
import DegreeCourses from '@/page/DegreeCourses/DegreeCourses'
import QuestionBank from '@/page/QuestionBank/QuestionBank'
import StudentAchievement from '@/page/StudentAchievement/StudentAchievement'
import Signin from '@/page/Signin/Signin'
import ShoppingCart from '@/page/ShoppingCart/ShoppingCart'
import Buy from '@/page/Buy/Buy'
import MyOrder from "@/page/MyOrder/MyOrder";


Vue.use(Router);

export default new Router({
    mode: 'history',
    routes: [
        {
            path: '*',
            redirect: '/home'
        },
        // 首页
        {
            path: '/home',
            name: 'home',
            component: Home
        },
        // 免费课
        {
            path: '/free_class',
            name: 'free_class',
            component: FreeClass
        },
        // 免费课详情
        {
            path: '/free_class/:id',
            name: 'free_class_detail',
            component: FreeClassDetail
        },
        // 轻课
        {
            path: '/light_course',
            name: 'light_course',
            component: LightLesson,
            meta: {
                requireAuth: true
            }
        },
        // 学位课
        {
            path: '/degree_courses',
            name: 'degree_courses',
            component: DegreeCourses
        },
        // 题库
        {
            path: '/question_bank',
            name: 'question_bank',
            component: QuestionBank
        },
        // 学员成果
        {
            path: '/student_achievement',
            name: 'student_achievement',
            component: StudentAchievement
        },
        // 登陆
        {
            path: '/signin',
            name: 'signin',
            component: Signin
        },
        // 购物车
        {
            path: '/shopping-cart',
            name: 'shopping_cart',
            component: ShoppingCart,
            meta: {
                requireAuth: true
            }
        },
        // 结算
        {
            path: '/buy',
            name: 'buy',
            component: Buy,
            meta: {
                requireAuth: true
            }
        },
        // 我的订单
        {
            path: '/my-order',
            name: 'my_order',
            component: MyOrder,
            meta: {
                requireAuth: true
            }
        }
    ]
})
