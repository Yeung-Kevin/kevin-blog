<template>
    <div class="header">
        <div class="header_cont">
            <div class="left">
                <router-link :to="{name:'home'}"><img class="oldboy" src="./img/logo.png"></router-link>
                <ul class="nav">
                    <li>
                        <router-link :to="{name:'free_class'}">免费课</router-link>
                    </li>
                    <li>
                        <router-link :to="{name:'light_course'}">轻课</router-link>
                    </li>
                    <li>
                        <router-link :to="{name:'degree_courses'}">学位课</router-link>
                    </li>
                    <li>
                        <router-link :to="{name:'question_bank'}">题库</router-link>
                    </li>
                    <li class="stu_ach">
                        <router-link :to="{name:'student_achievement'}">学员成果</router-link>
                    </li>
                </ul>
                <div class="studentNum">
                    <img alt="" src="//hcdn1.luffycity.com/static/frontend/index/学员成果标签@2x_1560584351.8454087.png">
                    <span>26672</span>
                </div>
            </div>
            <div class="header_right_box">
                <div class="shop_car" v-if="token" @click="jump_shopping_cart">
                    <i class="fa fa-shopping-cart"></i>
                    <span>购物车</span>
                </div>
                <div class="register" v-if="!token">
                    <span><router-link :to="{name:'signin'}">登录</router-link></span>
                    <span>&nbsp;&nbsp;|&nbsp;&nbsp;</span>
                    <span>注册领教材</span>
                </div>
                <div class="nav_right_box" v-else>
                    <div class="nav_right" @mouseleave="mouseleaveHide">
                        <div class="nav_study">学习中心</div>
                        <div class="nav_img" @mouseenter="mouseenterShow">
                            <img src="./img/logo@2x.png" alt="">
                        </div>
                        <ul class="my_account" v-show="isShow">
                            <li>我的账户 <!--<i class="fa fa-angle-right sec-arrow-icon"></i>--></li>
                            <li><router-link :to="{name:'my_order'}">我的订单 <!--<i class="fa fa-angle-right sec-arrow-icon"></i>--></router-link></li>
                            <li>我的优惠券 <!--<i class="fa fa-angle-right sec-arrow-icon"></i>--></li>
                            <li><span>我的消息<b>()</b><!--v-if--></span><!--<i class="fa fa-angle-right sec-arrow-icon"></i>--></li>
                            <li @click="out">退出<!--<i class="fa fa-angle-right sec-arrow-icon"></i>--></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    import {mapState, mapMutations} from 'vuex'
    import {LOGOUT} from '../../store/mutations-types'

    export default {
        name: "Header",
        data() {
            return {
                isShow: false
            }
        },
        computed: {
            ...mapState(['token'])
        },
        methods: {
            ...mapMutations([LOGOUT]),
            mouseenterShow() {
                this.isShow = true;
            },
            mouseleaveHide() {
                this.isShow = false;
            },
            out() {
                this.isShow = false;
                this.logout();
            },
            jump_shopping_cart() {
                this.$router.push({name: 'shopping_cart'})
            }
        },
        mounted() {

        }
    }
</script>

<style scoped>
    .header {
        width: 100%;
        height: 80px;
        background: #fff;
        /*position: fixed;
        left: 0;
        top: 40px;*/
        margin: 0 auto;
        display: -ms-flexbox;
        display: flex;
        z-index: 7;
        text-overflow: ellipsis;
        white-space: nowrap;
        box-shadow: 0 0.5px 0.5px 0 #c9c9c9;
        border-bottom: 1px solid #c9c9c9;
    }

    .header .header_cont {
        width: 1200px;
        height: 100%;
        display: -ms-flexbox;
        display: flex;
        -ms-flex-align: center;
        align-items: center;
        -ms-flex-pack: justify;
        justify-content: space-between;
        margin: 0 auto;
    }

    .header .header_cont .left {
        display: -ms-flexbox;
        display: flex;
        -ms-flex-align: center;
        align-items: center;
        position: relative;
    }

    .header .header_cont .oldboy {
        width: 118px;
        height: auto;
        cursor: pointer;
        margin-right: 50px;
    }

    .nav > li {
        position: relative;
        display: block;
    }

    .header .header_cont .nav {
        width: auto;
        height: 90%;
        font-size: 14px;
        color: #5e5e5e;
        display: -ms-flexbox;
        display: flex;
        line-height: 80px;
        cursor: pointer;
        position: relative;
    }


    .header .header_cont .nav li {
        margin-right: 30px;
        margin-top: -2px;
    }

    .header .header_cont .nav a {
        text-align: center;
        padding-bottom: 16px;
        padding-left: 5px;
        padding-right: 5px;
        position: relative;
        font-size: 16px;
        color: #4a4a4a;
    }


    .header .header_cont .nav a:last-child {
        margin-right: 0;
    }

    .header .header_cont .nav .router-link-active {
        color: #4a4a4a;
        border-bottom: 4px solid #000;
    }


    .header .header_cont .left .studentNum {
        position: absolute;
        top: 18px;
        left: 558px;
        cursor: pointer;
    }

    .header .header_cont .left .studentNum img {
        width: 64px;
        height: 34px;
        text-align: center;
        transform: scale(.8);
        position: absolute;
        left: -9px;
        top: -15px;
    }

    .header .header_cont .left .studentNum span {
        font-size: 14px;
        color: #fff;
        line-height: 17px;
        text-align: center;
        transform: scale(.8);
        position: absolute;
        left: 2px;
        top: -8px;
    }

    .header .header_cont .header_right_box {
        height: auto;
        display: -ms-flexbox;
        display: flex;
        -ms-flex-align: center;
        align-items: center;
        font-size: 15px;
        color: #4a4a4a;
    }

    .header .header_cont .header_right_box .shop_car {
        width: 88px;
        height: 28px;
        margin-right: 20px;
        background: #f7f7f7;
        border-radius: 17px;
        display: -ms-flexbox;
        display: flex;
        -ms-flex-align: center;
        align-items: center;
        -ms-flex-pack: distribute;
        justify-content: space-around;
        cursor: pointer;
        position: relative;
        font-size: 14px;
    }

    .header .header_cont .header_right_box .shop_car img {
        width: 15px;
        height: auto;
        margin-left: 6px;
    }

    .header .header_cont .header_right_box .shop_car span {
        margin-right: 6px;
    }

    .header .header_cont .header_right_box .register {
        text-align: right;
    }

    .header .header_cont .header_right_box .register span {
        cursor: pointer;
    }

    .header .header_cont .header_right_box .nav_right_box {
        position: relative;
    }

    .header .header_cont .header_right_box .nav_right_box .nav_right {
        float: right;
        display: -ms-flexbox;
        display: flex;
        height: 100%;
        line-height: 80px;
        position: relative;
    }

    .header .header_cont .header_right_box .nav_right_box .nav_right div:first-child {
        padding-left: 0;
    }

    .header .header_cont .header_right_box .nav_right_box .nav_right .nav_study {
        letter-spacing: 0;
        margin-right: 20px;
    }


    .header .header_cont .header_right_box .nav_right_box .nav_right div {
        line-height: 80px;
        cursor: pointer;
    }

    .header .header_cont .header_right_box .nav_right_box .nav_right .my_account {
        width: 180px;
        height: auto;
        position: absolute;
        right: -39px;
        top: 80px;
        z-index: 100;
        background: #fff;
        border-top: 2px solid #d0d0d0;
        box-shadow: 0 2px 4px 0 #e8e8e8;
    }

    .header .header_cont .header_right_box .nav_right_box .nav_right .my_account li {
        display: block;
        height: 40px;
        color: #4a4a4a;
        padding-left: 20px;
        padding-right: 20px;
        font-size: 13px;
        display: -ms-flexbox;
        display: flex;
        -ms-flex-align: center;
        align-items: center;
        -ms-flex-pack: justify;
        justify-content: space-between;
        cursor: pointer;
    }

    .header .header_cont .header_right_box .nav_right_box .nav_right .my_account li:hover {
        background: #ddd;
    }

    .header .header_cont .header_right_box .nav_right_box .nav_right .my_account li i {
        float: right;
        font-size: 16px;
        color: #626262;
    }

    .header .header_cont .header_right_box .nav_right_box .nav_right .nav_img img {
        width: 26px;
        height: 26px;
        border-radius: 50%;
        display: inline-block;
        border: 1px solid #f3f3f3;
        position: relative;
        top: 10px;
    }
</style>
