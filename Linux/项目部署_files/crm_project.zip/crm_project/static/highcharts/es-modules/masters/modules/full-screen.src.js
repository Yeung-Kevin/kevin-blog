/**
 * @license @product.name@ JS v@product.version@ (@product.date@)
 * @module highcharts/modules/full-screen
 * @requires highcharts
 *
 * Advanced Highstock tools
 *
 * (c) 2010-2019 Highsoft AS
 * Author: Torstein Honsi
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../modules/full-screen.src.js';
