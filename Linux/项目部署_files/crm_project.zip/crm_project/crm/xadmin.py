import datetime
from django.db.models import Q
from .models import *
from django.conf.urls import url
from django.utils.safestring import mark_safe
from django.shortcuts import render, HttpResponse, redirect
from xadmin.service.xadmin import site, ModelXadmin
from django.http import JsonResponse


# 员工
class UserConfig(ModelXadmin):
    list_display = ['id', 'name', 'email', 'depart']


site.register(UserInfo, UserConfig)


# 部门
class DepartmentConfig(ModelXadmin):
    list_display = ['title', 'code']


site.register(Department, DepartmentConfig)

# 课程
site.register(Course)

# 学校
site.register(School)


# 班级
class ClassConfig(ModelXadmin):
    def display_classname(self, obj=None, header=False):
        if header:
            return '班级名称'
        class_name = '%s(%s期)' % (obj.course, obj.semester)
        return class_name

    list_display = [display_classname, 'tutor', 'teachers']


site.register(ClassList, ClassConfig)


# 客户
class CustomerConfig(ModelXadmin):
    """
    客户这里还缺少一个功能就是编写一个脚本每晚12点执行该脚本检测每个客户的状态是否过期了然后将该用户转为公共用户
    """

    def display_gender(self, obj=None, header=False):
        if header:
            return '性别'
        return obj.get_gender_display()

    def display_course(self, obj=None, header=False):
        if header:
            return '咨询课程（点击删除课程）'
        temp = []
        for course in obj.course.all():
            s = "<a href='/xadmin/crm/customer/cancel_course/%s/%s' style='border:1px solid #369;padding:3px 6px'><span>%s</span></a>&nbsp;" % (obj.pk, course.pk, course.name,)
            temp.append(s)
        return mark_safe("".join(temp))

    # 删除课程的视图
    def cancel_course(self, request, customer_id, course_id):
        obj = Customer.objects.filter(pk=customer_id).first()
        obj.course.remove(course_id)
        return redirect(self.get_list_url())

    # 公共客户视图
    def public_customer(self, request):
        """
            公共客户的条件:

                三天跟进: 当前时间 - 最后一次跟进时间 > 3 ----> 当前时间 - 3 > 最后一次跟进时间 ----> 最后一次跟进时间 < 当前时间 - 3
                15天未成单: 当前时间 - 接单时间 > 15 ----> 当前时间 - 15 > 接单时间 ----> 接单时间 < 当前时间 - 15
                consultant_id != this.userid  -> 当前用户无法看回自己的客户变成公共客户的客户
                未报名
        """
        now = datetime.datetime.now()
        delta_day3 = datetime.timedelta(days=3)  # 获取当前时间之后3天的日期对象
        delta_day15 = datetime.timedelta(days=15)  # 获取当前时间之后15天的日期对象
        # user_id = 12  # 模拟当前用户id
        session_user_id = request.session['user_id']  # 这里获取的是User表的id而不是UserInfo表的id
        user_id = UserInfo.objects.filter(user_id=session_user_id).first().pk  # 获取UserInfo表的id
        customer_list = Customer.objects.filter(Q(last_consult_date__lt=now - delta_day3) | Q(recv_date__lt=now - delta_day15)).exclude(Q(consultant=user_id) | Q(status=1))
        return render(request, 'public_customer.html', {'customer_list': customer_list})

    # 确认跟进公共用户的接口
    def follow(self, request, cid):
        # user_id = 12  # 模拟当前用户id
        session_user_id = request.session['user_id']  # 这里获取的是User表的id而不是UserInfo表的id
        user_id = UserInfo.objects.filter(user_id=session_user_id).first().pk  # 获取UserInfo表的id
        now = datetime.datetime.now()
        delta_day3 = datetime.timedelta(days=3)  # 获取当前时间之后3天的日期对象
        delta_day15 = datetime.timedelta(days=15)  # 获取当前时间之后15天的日期对象
        ret = Customer.objects.filter(Q(last_consult_date__lt=now - delta_day3) | Q(recv_date__lt=now - delta_day15), pk=cid).exclude(status=1).update(consultant=user_id, last_consult_date=now, recv_date=now)

        if not ret:  # 防止两个用户同时抢单所出现的问题
            return HttpResponse('已经被跟进')

        obj = CustomerDistrbute.objects.create(customer_id=cid, consultant_id=user_id, date=now, status=1)

        return redirect('/xadmin/crm/customer/my_customer/')

    # 我的客户视图
    def my_customer(self, request):
        # user_id = 12  # 模拟当前用户id
        session_user_id = request.session['user_id']  # 这里获取的是User表的id而不是UserInfo表的id
        user_id = UserInfo.objects.filter(user_id=session_user_id).first().pk  # 获取UserInfo表的id
        customer_distrbute_list = CustomerDistrbute.objects.filter(consultant=user_id)
        return render(request, 'my_customer.html', {
            'customer_distrbute_list': customer_distrbute_list
        })

    # 扩展url
    def extra_url(self):
        temp = []
        temp.append(url(r"cancel_course/(\d+)/(\d+)", self.cancel_course))  # 取消课程
        temp.append(url(r"public/", self.public_customer))  # 公共客户
        temp.append(url(r"follow/(\d+)/", self.follow))  # 确认跟进
        temp.append(url(r"my_customer/", self.my_customer))  # 我的客户
        return temp

    list_display = ['name', display_gender, display_course, 'consultant']


site.register(Customer, CustomerConfig)


# 客户跟进记录
class ConsultConfig(ModelXadmin):
    list_display = ['customer', 'consultant', 'date', 'note']


site.register(ConsultRecord, ConsultConfig)


# 客户分布

class CustomerDistrbuteConfig(ModelXadmin):
    list_display = ['customer', 'consultant', 'date', 'status']


site.register(CustomerDistrbute, CustomerDistrbuteConfig)


# 学生
class StudentConfig(ModelXadmin):
    def score_view(self, request, sid):
        # 查看成绩的接口
        if request.is_ajax():
            cid = request.GET.get('cid')
            study_record_list = StudyRecord.objects.filter(student=sid, course_record__class_obj=cid)
            data_list = []
            for study_record in study_record_list:
                day_num = study_record.course_record.day_num
                data_list.append(['day%s' % day_num, study_record.score])
            return JsonResponse(data_list, safe=False)

        # 返回相应数据
        student = Student.objects.filter(customer_id=sid).first()
        class_list = student.class_list.all()
        return render(request, 'view_grades.html', {
            'student': student,
            'class_list': class_list
        })

    def extra_url(self):
        temp = []
        temp.append(url(r'score_view/(\d+)/', self.score_view))
        return temp

    def score_show(self, obj=None, header=False):
        if header:
            return '查看成绩'
        return mark_safe('<a href="/xadmin/crm/student/score_view/%s/">查看成绩</a>' % obj.pk)

    list_display = ['customer', 'class_list', score_show]
    list_display_links = ['customer']


site.register(Student, StudentConfig)


# 上课记录表（班级记录，即：当天的课程记录）
class CourseConfig(ModelXadmin):
    def score(self, request, course_record_id):
        if request.method == 'POST':
            data = {}
            for key, value in request.POST.items():

                if key == "csrfmiddlewaretoken":
                    continue  # 跳出本次循环

                field, pk = key.rsplit('_', 1)

                if pk in data:
                    data[pk][field] = value
                else:
                    data[pk] = {field: value}

            for pk, update_data in data.items():
                StudyRecord.objects.filter(pk=pk).update(**update_data)

            return redirect(request.path)
        else:
            study_record_list = StudyRecord.objects.filter(course_record__id=course_record_id)
            score_choices = StudyRecord.score_choices
            return render(request, 'score.html', {
                'study_record_list': study_record_list,
                'score_choices': score_choices
            })

    # 扩展url
    def extra_url(self):
        temp = []
        temp.append(url(r'entering_grades/(\d+)', self.score))
        return temp

    # 考勤
    def attendance(self, obj=None, header=False):
        if header:
            return '考勤'
        return mark_safe('<a href="/xadmin/crm/studyrecord/?course_record=%s">考勤</a>' % obj.pk)

    # 录入成绩
    def entering_grades(self, obj=None, header=False):
        if header:
            return '录入成绩'
        return mark_safe('<a href="entering_grades/%s">录入成绩</a>' % obj.pk)

    list_display = ['class_obj', 'day_num', 'teacher', attendance, entering_grades]

    # 批量生成学生记录
    def patch_studyrecord(self, request, queryset):
        temp = []
        for course_record in queryset:
            student_list = Student.objects.filter(class_list__id=course_record.class_obj.pk)
            for student in student_list:
                obj = StudyRecord(student=student, course_record=course_record, homework_note='')
                temp.append(obj)
        StudyRecord.objects.bulk_create(temp)

    patch_studyrecord.short_description = '批量生成学生记录'
    actions = [patch_studyrecord]


site.register(CourseRecord, CourseConfig)


# 学习记录
class StudyConfig(ModelXadmin):
    list_display = ['student', 'course_record', 'record', 'score']

    # 考勤
    def patch_late(self, request, queryset):
        queryset.update(record="late")

    patch_late.short_description = '迟到'
    actions = [patch_late]


site.register(StudyRecord, StudyConfig)
