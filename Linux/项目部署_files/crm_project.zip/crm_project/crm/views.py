from django.shortcuts import render, HttpResponse, redirect
from rbac.models import *
from rbac.service.perssions import *


# 登陆
def login(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        user_obj = User.objects.filter(name=username, password=password).first()
        if user_obj:
            request.session['user_id'] = user_obj.pk  # 在 session 中注册当前用户的 id

            initial_session(user_obj, request)  # 在 session 中注册当前用户的权限列表，因为注册权限列表和rbac有关所以才写到rbac组件中

            url = request.session['menu_permission_list'][0]['url']

            # return HttpResponse('登陆成功')
            return redirect(url)
        else:
            return HttpResponse('登陆失败')

    return render(request, 'login.html')
