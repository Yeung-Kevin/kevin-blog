from xadmin.service.xadmin import site, ModelXadmin
from .models import *


# 用户
class UserConfig(ModelXadmin):
    list_display = ['name', 'password', 'roles']


site.register(User, UserConfig)


# 角色
class RoleConfig(ModelXadmin):
    list_display = ['title', 'permissions']


site.register(Role, RoleConfig)


# 权限
class PermissionConfig(ModelXadmin):
    list_display = ['title', 'url', 'action', 'group']


site.register(Permission, PermissionConfig)


# 权限分组
class PermissionGroupConfig(ModelXadmin):
    list_display = ['title']


site.register(PermissionGroup, PermissionGroupConfig)


# 操作类别
class OperationCategoryConfig(ModelXadmin):
    list_display = ['title']


site.register(OperationCategory, OperationCategoryConfig)
