import re
from django.utils.deprecation import MiddlewareMixin
from django.shortcuts import HttpResponse, redirect


class ValidPermission(MiddlewareMixin):

    def process_request(self, request):

        current_path = request.path_info  # 获取当前访问路径，且不带域名+端口 和 参数

        # 检测是否是白名单
        valid_url_list = ['/login/', '/reg/', '/admin/.*']

        for valid_url in valid_url_list:
            ret = re.match(valid_url, current_path)  # 使用正则判断当前路径是否在白名单里
            if ret:
                return None

        # 验证是否已经登录
        user_id = request.session.get('user_id')

        if not user_id:
            return redirect('/login/')

        # 验证用户是否有权限访问当前路径一
        # permission_list = request.session.get('permission_list', [])  # 获取当前用户的所有权限 -> 获取到的数据结构 ['/users/', '/users/add', '/users/delete/(\\d+)']
        #
        # flag = False
        # for permission in permission_list:
        #     permission = '^%s$' % permission
        #     ret = re.match(permission, current_path)  # 使用正则判断当前用户权限里有没有当前访问的路径，如果没有就说明没有访问权限
        #     if ret:
        #         flag = True
        #         break
        #
        # if not flag:
        #     return HttpResponse('没有访问权限')
        #
        # return None

        # 验证用户是否有权限访问当前路径二
        permission_dict = request.session.get('permission_dict', {})
        # permission_dict的数据结构 -> 一个分组就代表一个网页（例: user.html 下有增删改查的操作）
        #
        # key 代表分组id -> 一个分组就代表一个网页（例: user.html 下有增删改查的操作）
        # values 存放着相关权限和相关操作类别
        #
        # {
        #     1: {
        #         'urls': ['/user/', '/user/add/', '/user/edit/(\\d+)', '/user/delete/(\\d+)'],
        #         'actions': ['look', 'add', 'edit', 'delete']
        #     },
        #     2: {
        #         'urls': ['/roles/', '/roles/add/', '/roles/edit/(\\d+)', '/roles/delete/(\\d+)'],
        #         'actions': ['look', 'add', 'edit', 'delete']
        #     }
        # }

        for i in permission_dict.values():  # 循环字典中的每一个value值
            urls = i['urls']
            for reg in urls:
                reg = '^%s$' % reg
                ret = re.match(reg, current_path)
                if ret:
                    request.actions = i['actions']
                    return None

        return HttpResponse('没有访问权限')
