def initial_session(user_obj, request):
    # 方案一 -> 生成一个数据结构，用于根据权限判断增删改按钮的显示与隐藏
    # permissions = user_obj.roles.all().values('permissions__url').distinct()  # 查询该用户的所有权限并且进行去重
    #
    # permission_list = []
    # for item in permissions:
    #     permission_list.append(item["permissions__url"])
    #
    # request.session["permission_list"] = permission_list  # 将查询到的权限设置到session中

    # 方案二 -> 生成一个数据结构，用于根据权限判断增删改按钮的显示与隐藏 和 验证用户是否有权限访问当前路径
    permissions = user_obj.roles.all().values('permissions__url', 'permissions__group_id', 'permissions__action__title').distinct()  # 查询到的数据结构：<QuerySet [{'permissions__group_id': 1, 'permissions__url': '/user/', 'permissions__action__title': 'look'}, ……]>
    permission_dict = {}
    for i in permissions:
        group_id = i.get('permissions__group_id')  # 分组id

        if group_id in permission_dict:
            permission_dict[group_id]['urls'].append(i.get('permissions__url'))
            permission_dict[group_id]['actions'].append(i.get('permissions__action__title'))
        else:
            permission_dict[group_id] = {
                'urls': [i.get('permissions__url')],
                'actions': [i.get('permissions__action__title')]
            }

    # permission_dict 的数据结构
    #
    # key 代表分组id -> 一个分组就代表一个网页（例: user.html 下有增删改查的操作）
    # values 存放着相关权限和相关操作类别
    #
    # {
    #     1: {
    #         'urls': ['/user/', '/user/add/', '/user/edit/(\\d+)', '/user/delete/(\\d+)'],
    #         'actions': ['look', 'add', 'edit', 'delete']
    #     },
    #     2: {
    #         'urls': ['/roles/', '/roles/add/', '/roles/edit/(\\d+)', '/roles/delete/(\\d+)'],
    #         'actions': ['look', 'add', 'edit', 'delete']
    #     }
    # }

    request.session['permission_dict'] = permission_dict  # 将查询到的权限设置到session中

    # 菜单权限的数据结构 -> 作用: 根据用户的权限显示该用户对应的权限菜单

    permissions2 = user_obj.roles.all().values('permissions__url', 'permissions__action__title', 'permissions__title').distinct()  # <QuerySet [{'permissions__url': '/user/', 'permissions__action__title': 'look', 'permissions__group__title': '用户组'}, ……]>

    menu_permission_list = []
    for i in permissions2:
        if i['permissions__action__title'] == 'look':
            menu_permission_list.append({
                'group_title': i['permissions__title'],
                'url': i['permissions__url']
            })
    # menu_permission_list 的数据结构 ：[{'url': '/user/', 'group_title': '用户组'}, {'url': '/roles/', 'group_title': '角色组'}]

    request.session['menu_permission_list'] = menu_permission_list
