from django.db import models


# 用户表
class User(models.Model):
    name = models.CharField(max_length=32, verbose_name='用户名')
    password = models.CharField(max_length=32, verbose_name='密码')
    roles = models.ManyToManyField(to='Role', verbose_name='角色')

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = "用户表"
        verbose_name_plural = verbose_name


# 角色表
class Role(models.Model):
    title = models.CharField(max_length=32, verbose_name='角色名称')
    permissions = models.ManyToManyField(to='Permission', verbose_name='权限')

    def __str__(self):
        return self.title

    class Meta:
        verbose_name = "角色表"
        verbose_name_plural = verbose_name


# 权限表
class Permission(models.Model):
    title = models.CharField(max_length=32, verbose_name='权限名称')
    url = models.CharField(max_length=64, verbose_name='路径')
    action = models.ForeignKey(to='OperationCategory', verbose_name='操作类别')
    group = models.ForeignKey(to='PermissionGroup', verbose_name='分组')

    def __str__(self):
        return self.title

    class Meta:
        verbose_name = "权限表"
        verbose_name_plural = verbose_name


# 权限分组表 -> 一个分组就代表一个网页（例: user.html 下有增删改查的操作）
class PermissionGroup(models.Model):
    title = models.CharField(max_length=32, verbose_name='分组名称')

    def __str__(self):
        return self.title

    class Meta:
        verbose_name = "权限分组表"
        verbose_name_plural = verbose_name


# 操作类别
class OperationCategory(models.Model):
    title = models.CharField(max_length=32, verbose_name='操作类别名称')

    def __str__(self):
        return self.title

    class Meta:
        verbose_name = "操作类别表"
        verbose_name_plural = verbose_name
