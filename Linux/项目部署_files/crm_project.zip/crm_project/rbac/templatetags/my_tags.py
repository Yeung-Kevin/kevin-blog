from django import template
from rbac.models import *

register = template.Library()


@register.inclusion_tag('header.html')
def get_header(request):
    user_id = request.session['user_id']
    username = User.objects.filter(pk=user_id).first().userinfo.name
    return {'username': username}


@register.inclusion_tag('menu.html')
def get_menu(request):
    # 获取当前用户可以放到菜单栏中的权限
    menu_permission_list = request.session["menu_permission_list"]
    return {'menu_permission_list': menu_permission_list}
