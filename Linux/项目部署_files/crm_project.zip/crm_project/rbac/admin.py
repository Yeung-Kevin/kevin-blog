from django.contrib import admin
from .models import *


class UserAdmin(admin.ModelAdmin):
    list_display = ['name', 'password', 'show_roles']

    def show_roles(self, obj):
        role_list = []
        for role in obj.roles.all():
            role_list.append(role.title)
        return ','.join(role_list)

    show_roles.short_description = '角色'


admin.site.register(User, UserAdmin)


class RoleAdmin(admin.ModelAdmin):
    list_display = ['title', 'show_permissions']

    def show_permissions(self, obj):
        permissions_list = []
        for permissions in obj.permissions.all():
            permissions_list.append(permissions.title)
        return '，'.join(permissions_list)

    show_permissions.short_description = '权限'


admin.site.register(Role, RoleAdmin)


class PermissionAdmin(admin.ModelAdmin):
    list_display = ['title', 'url', 'action', 'group']


admin.site.register(Permission, PermissionAdmin)


class PermissionGroupAdmin(admin.ModelAdmin):
    list_display = ['title']


admin.site.register(PermissionGroup, PermissionGroupAdmin)


class OperationCategoryAdmin(admin.ModelAdmin):
    list_display = ['title']


admin.site.register(OperationCategory, OperationCategoryAdmin)
