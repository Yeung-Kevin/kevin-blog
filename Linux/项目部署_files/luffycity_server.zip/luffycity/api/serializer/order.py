from rest_framework import serializers
from api.models import *


# 订单
class OrderSerializers(serializers.ModelSerializer):
    status_txt = serializers.CharField(source='get_status_display')
    date = serializers.DateTimeField(format="%Y-%m-%d %H:%M:%S")
    course = serializers.SerializerMethodField()

    class Meta:
        model = Order
        fields = ['id', 'order_number', 'date', 'actual_amount', 'deductible_amount', 'status', 'status_txt', 'course']

    def get_course(self, obj):
        temp = []
        for order_detail in obj.orderdetail_set.all():
            print(order_detail.content_object.course_img)
            temp.append({
                'course_id': order_detail.content_object.pk,
                'course_name': order_detail.content_object.name,
                'course_img': order_detail.content_object.course_img,
                'valid_period_display': order_detail.valid_period_display,
                'original_price': order_detail.original_price,
                'price': order_detail.price
            })
        return temp
