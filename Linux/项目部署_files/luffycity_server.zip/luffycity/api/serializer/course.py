from rest_framework import serializers
from api.models import *


# 课程
class CourseSerializers(serializers.ModelSerializer):
    level = serializers.CharField(source='get_level_display')

    class Meta:
        model = Course
        fields = ['id', 'name', 'course_img', 'level']


# 课程详情
class CourseDetailSerializers(serializers.ModelSerializer):
    course_id = serializers.IntegerField(source='course.pk')
    name = serializers.CharField(source='course.name')
    img = serializers.CharField(source='course.course_img')
    level = serializers.CharField(source='course.get_level_display')
    price_policy = serializers.SerializerMethodField()
    recommend_courses = serializers.SerializerMethodField()

    # chapter = serializers.SerializerMethodField()

    class Meta:
        model = CourseDetail
        fields = ['id', 'course_id', 'name', 'img', 'level', 'hours', 'recommend_courses', 'price_policy']

    def get_recommend_courses(self, obj):
        """
        获取推荐课程
        """
        temp = []
        for course in obj.recommend_courses.all():
            temp.append({
                'id': course.id,
                'name': course.name
            })
        return temp

    def get_price_policy(self, obj):
        temp = []
        for price_policy in obj.course.price_policy.all():
            temp.append({
                'price_policy_id': price_policy.pk,
                'valid_period': price_policy.valid_period,
                'valid_period_txt': price_policy.get_valid_period_display(),
                'price': price_policy.price,
            })
        return temp

    # def get_chapter(self, obj):
    #     """
    #     获取章节
    #     """
    #     chapter_queryset = obj.course.chapter_set.all()
    #     return [{'id': key.id, 'chapter_num': key.chapter_num, 'name': key.name} for key in chapter_queryset]
