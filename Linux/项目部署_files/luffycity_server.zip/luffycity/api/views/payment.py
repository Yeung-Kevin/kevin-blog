from rest_framework.views import APIView
from rest_framework.response import Response

from django.core.exceptions import ObjectDoesNotExist

from api.models import *
from api.util.auth import TokenAuth
from api.util.pay import AliPay
from api.util.response import BaseResponse
from api.util.exceptions import CommonException

import datetime
import time
import uuid


class PaymentView(APIView):
    authentication_classes = [TokenAuth]

    def get_alipay(self):
        # 沙箱环境地址：https://openhome.alipay.com/platform/appDaily.htm?tab=info
        app_id = "2016100100639453"
        # 一定要使用公网IP否则支付宝无法找到，因为公网无法找到局域网的IP
        notify_url = "http://47.94.172.250:8804/page2/"  # 如果支付成功，支付宝会向该地址发送 POST 请求，用于支付成功后的后续处理 和 数据验证
        # 这个可以使用局域网IP
        return_url = "http://127.0.0.1:8080/my-order"  # 如果支付成功，支付宝会向该地址发送 GET 请求，用于页面跳转（重定向）
        merchant_private_key_path = "keys/app_private_2048.txt"
        alipay_public_key_path = "keys/alipay_public_2048.txt"

        alipay = AliPay(
            appid=app_id,
            app_notify_url=notify_url,
            return_url=return_url,
            app_private_key_path=merchant_private_key_path,  # 商户的私钥
            alipay_public_key_path=alipay_public_key_path,  # 支付宝的公钥，验证支付宝回传消息使用，不是你自己的公钥
            debug=True,  # 默认False,  等于True调校到沙箱环境，等于False提交到正式环境
        )
        return alipay

    # 获取优惠券对象
    def get_coupon(self, request, coupon_id, course_id=None):
        now = datetime.datetime.now()
        coupon = Coupon.objects.filter(
            pk=coupon_id,
            couponrecord__account=request.user,  # 当前用户
            couponrecord__status=0,  # 优惠券未使用
            content_type=8,  # django_content_type 的 id
            object_id=course_id,  # 课程id
            valid_begin_date__lte=now,  # 当前时间大于等于优惠券开始时间
            valid_end_date__gte=now,  # 当前时间小于等于优惠券结束时间
        ).first()
        return coupon

    # 获取折后价
    def cal_coupon_price(self, price, coupon_info):
        coupon_type = coupon_info.get_coupon_type_display()  # 优惠券类型
        money_equivalent_value = coupon_info.money_equivalent_value  # 等值货币
        minimum_consume = coupon_info.minimum_consume  # 最低消费金额
        off_percent = coupon_info.off_percent  # 折扣百分比
        ad_price = 0

        if coupon_type == '立减券':
            ad_price = price - money_equivalent_value
            if ad_price <= 0:
                ad_price = 0
        elif coupon_type == '满减券':
            if price > minimum_consume:
                ad_price = price - money_equivalent_value
            else:
                raise CommonException(0, '没有达到最低消费金额')
        elif coupon_type == '折扣券':
            ad_price = price * off_percent / 100
        return ad_price

    # 结算前验证 + 生成订单 +支付宝支付功能 -> 不要从缓存中获取课程数据，重新从数据库中获取
    def post(self, request, *args, **kwargs):
        """
        前端发送过来的数据
        {
            course_list:[
                {
                    course_id: 1,  # 课程id
                    default_price_policy_id: 1,  # 价格策略
                    coupon_record_id: 2,  # 优惠券id
                    original_price: 1000,  // 原价
                    price: 1000, // 折后价
                    valid_period_display: 7周, // 有效期
                },{
                    course_id:2
                    default_price_policy_id:4,
                    coupon_record_id:6,
                    original_price: 1000,  // 原价
                    price: 1000, // 折后价
                    valid_period_display: 7周, // 有效期
                }
            ],
            global_coupon_id: 3  # 公共优惠券id
            pay_money: 100  # 支付价格
            deductible_amount: 0 # 抵扣金额
        }
        """
        res = BaseResponse()
        try:
            # 获取需要验证的数据
            user_id = request.user.id
            course_list = request.data.get('course_list')
            global_coupon_id = request.data.get('global_coupon_id')
            pay_money = request.data.get('pay_money')
            deductible_amount = request.data.get('deductible_amount')

            price_list = []

            # 验证每一个课程
            for course_obj in course_list:
                course_id = course_obj.get('course_id')  # 课程id
                default_price_policy_id = course_obj.get('default_price_policy_id')  # 价格策略
                coupon_record_id = course_obj.get('coupon_record_id')  # 优惠券id

                # 验证课程是否存在
                course = Course.objects.get(pk=course_id)

                # 验证价格策略是否存在
                price_obj = course.price_policy.filter(pk=default_price_policy_id).first()
                if not price_obj:
                    raise CommonException(0, '价格策略不存在')

                price = price_obj.price

                # 验证优惠券是否存在
                if coupon_record_id:

                    coupon = self.get_coupon(request, coupon_record_id, course_id)

                    if not coupon:
                        raise CommonException(0, '优惠券不存在')

                    ad_price = self.cal_coupon_price(price, coupon)
                    price_list.append(ad_price)
                else:
                    price_list.append(price)

            total_price = sum(price_list)  # 商品总价格

            # 验证公共优惠券是否存在
            if global_coupon_id:
                global_coupon = self.get_coupon(request, global_coupon_id)
                if not global_coupon:
                    raise CommonException(0, '公共优惠券不存在')
                pay_price = self.cal_coupon_price(total_price, global_coupon)
            else:
                pay_price = total_price

            # 验证价格是否异常
            if pay_price != float(pay_money):
                raise CommonException(0, '支付价格异常')

            # 生成订单
            order_obj = Order.objects.create(
                payment_type=0,
                order_number=uuid.uuid4(),
                account=request.user,
                actual_amount=pay_price,
                deductible_amount=deductible_amount,
                status=1,
                order_type=0
            )

            for course_obj in course_list:
                OrderDetail.objects.create(
                    order=order_obj,
                    content_type_id=8,
                    object_id=course_obj.get('course_id'),
                    original_price=course_obj.get('original_price'),  # 课程原价
                    price=course_obj.get('price'),  # 折后价
                    valid_period_display=course_obj.get('valid_period_display')
                )

            # 生成支付的url
            alipay = self.get_alipay()
            query_params = alipay.direct_pay(
                subject="路飞学城",  # 商品简单描述
                out_trade_no="x345" + str(time.time()),  # 商户订单号
                total_amount=pay_price,  # 交易金额(单位: 元 保留俩位小数)
            )

            pay_url = "https://openapi.alipaydev.com/gateway.do?{}".format(query_params)  # 如果 AliPay 的debug参数等于False的时候，网址中的 dev 要去除掉

            res.data = {
                "url": pay_url
            }

        except ObjectDoesNotExist as e:
            res.msg = '课程不存在'
        except CommonException as e:
            res.msg = e.msg

        return Response(res.dic)
