from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import viewsets

from api import models
from api.serializer.course import (
    CourseSerializers,
    CourseDetailSerializers,
)

from api.util.auth import TokenAuth


# 免费课
class CourseView(viewsets.ViewSetMixin, APIView):
    def list(self, request, *args, **kwargs):

        """
        课程列表接口
        :param request:
        :param args:
        :param kwargs:
        :return:
        """
        ret = {'code': 0, 'data': None}
        try:
            course_queryset = models.Course.objects.all()
            ser = CourseSerializers(instance=course_queryset, many=True)
            ret['code'] = 1
            ret['data'] = ser.data
        except Exception as e:
            ret['error'] = '获取课程失败'
        return Response(ret)

    def retrieve(self, request, *args, **kwargs):

        """
        课程详情接口
        :param request:
        :param args:
        :param kwargs:
        :return:
        """

        ret = {'code': 1, 'data': None}
        try:
            pk = kwargs.get('pk')
            course_obj = models.CourseDetail.objects.filter(course_id=pk).first()
            ser = CourseDetailSerializers(instance=course_obj)
            ret['code'] = 1
            ret['data'] = ser.data
        except Exception as e:
            print(e)
            ret['error'] = '获取课程详情失败'
        return Response(ret)


# 轻课（有认证）
class LightCourseView(APIView):
    authentication_classes = [TokenAuth]

    def get(self, request, *args, **kwargs):
        if request.auth:
            return Response({'code': 1, 'msg': '从后台获取的数据'})
        else:
            return Response({'code': 0, 'error': '认证失败'})
