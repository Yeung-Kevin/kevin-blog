from rest_framework.views import APIView
from rest_framework.response import Response
from api.models import *
import uuid
import datetime


class SigninView(APIView):
    def post(self, request, *args, **kwargs):
        """
        用户登录验证
        :param request:
        :param args:
        :param kwargs:
        :return:
        """
        username = request.data.get('username')
        password = request.data.get('password')
        user = UserInfo.objects.filter(username=username, password=password).first()
        ret = {'code': 0}
        if user:
            uid = str(uuid.uuid4())
            ret['code'] = 1
            ret['token'] = uid
            UserToken.objects.update_or_create(user=user, defaults={'token': uid, 'created': datetime.datetime.now()})
        else:
            ret['error'] = '登录失败'
        return Response(ret)
