from rest_framework.views import APIView
from rest_framework.response import Response

from api.models import *
from api.util.auth import TokenAuth
from api.util.response import BaseResponse
from api.util.exceptions import CommonException

from django.conf import settings

import json
import redis
import datetime

POOL = redis.ConnectionPool(decode_responses=True)
R = redis.Redis(connection_pool=POOL)


class BuyView(APIView):
    authentication_classes = [TokenAuth]

    # 获取对应的优惠券方法
    def get_coupons(self, request, course_id=None):
        now = datetime.datetime.now()
        # 获取优惠券信息
        coupon_list_obj = Coupon.objects.filter(
            couponrecord__account=request.user,  # 当前用户
            couponrecord__status=0,  # 优惠券未使用
            content_type=8,  # django_content_type 的 id
            object_id=course_id,  # 课程id
            valid_begin_date__lte=now,  # 当前时间大于等于优惠券开始时间
            valid_end_date__gte=now,  # 当前时间小于等于优惠券结束时间
        )
        coupon_list = []
        for coupon in coupon_list_obj:
            coupon_list.append({
                'id': coupon.pk,
                'name': coupon.name,
                'coupon_type': coupon.coupon_type,
                'coupon_type_txt': coupon.get_coupon_type_display(),
                'money_equivalent_value': coupon.money_equivalent_value,
                'off_percent': coupon.off_percent,
                'minimum_consume': coupon.minimum_consume,
            })
        return coupon_list

    # 添加需要结算的课程信息到 Redis 中
    def post(self, request, *args, **kwargs):
        """
        模拟前端发送过来的数据:
            {
                "course_id_list":[1,2]
            }
        """
        res = BaseResponse()
        try:

            course_id_list = request.data.get('course_id_list')
            user_id = request.user.id

            # 清空所有结算缓存
            del_list = R.keys(settings.BUY_KEY % (user_id, '*'))
            if del_list:
                R.delete(*del_list)

            all_total_price_key = R.keys(settings.TOTAL_PRICE_KEY % '*')
            if all_total_price_key:
                R.delete(*all_total_price_key)

            price_list = []

            for course_id in course_id_list:
                buy_dict = {}
                buy_key = settings.BUY_KEY % (user_id, course_id)

                # 从购物车缓冲中获取课程信息，并且写入结算缓存中
                shoppingcar_key = settings.SHOPPINGCAR_KEY % (user_id, course_id)
                course_info = json.loads(R.get(shoppingcar_key))

                price_list.append(course_info['price'])

                course_info['default'] = '请选择'

                buy_dict['course_info'] = course_info

                # 获取当前用户所购买的课程所对应的优惠券，并且写入结算缓存中
                buy_dict['coupons'] = self.get_coupons(request, course_id)

                R.set(buy_key, json.dumps(buy_dict))

            # 获取当前用户的公共优惠券，并且写入结算缓存中
            global_coupons_key = settings.GLOBAL_COUPONS_KEY % user_id
            global_coupons_list = self.get_coupons(request)
            R.set(global_coupons_key, json.dumps(global_coupons_list))

            # 计算总价格并且写入缓存中
            total_price = sum(price_list)
            total_price_key = settings.TOTAL_PRICE_KEY % user_id
            R.set(total_price_key, total_price)

            res.code = 1
            res.data = '成功前往结算页面'

        except Exception as e:
            print(e)
            res.msg = '前往结算页面时发生错误'
        return Response(res.dic)

    # 查看需要结算的课程
    def get(self, request, *args, **kwargs):
        res = BaseResponse()
        try:
            user_id = request.user.id

            buy_info = {}

            # 获取课程信息 + 课程所对应的优惠券
            buy_key = settings.BUY_KEY % (user_id, '*')
            all_buy_key = R.scan_iter(buy_key)
            temp = []
            for key in all_buy_key:
                temp.append(json.loads(R.get(key)))
            buy_info['course_coupons'] = temp

            # 获取公共优惠券
            global_coupons_key = settings.GLOBAL_COUPONS_KEY % user_id
            buy_info['global_coupons'] = json.loads(R.get(global_coupons_key))

            # 获取商品总价格
            total_price_key = settings.TOTAL_PRICE_KEY % user_id
            total_price = json.loads(R.get(total_price_key))
            buy_info['total_price'] = json.loads(R.get(total_price_key))

            # 获取实付金额
            buy_info['real_payment'] = total_price

            res.data = buy_info
            res.code = 1
        except Exception as e:
            res.msg = '获取结算商品失败'
        return Response(res.dic)

    # 获取折后价
    def cal_coupon_price(self, price, coupon_info):
        coupon_type = coupon_info['coupon_type_txt']  # 优惠券类型
        money_equivalent_value = coupon_info['money_equivalent_value']  # 等值货币
        minimum_consume = coupon_info['minimum_consume']  # 最低消费金额
        off_percent = coupon_info['off_percent']  # 折扣百分比
        ad_price = 0

        if coupon_type == '立减券':
            ad_price = price - money_equivalent_value
            if ad_price <= 0:
                ad_price = 0
        elif coupon_type == '满减券':
            if price > minimum_consume:
                ad_price = price - money_equivalent_value
            else:
                raise CommonException(0, '没有达到最低消费金额')
        elif coupon_type == '折扣券':
            ad_price = price * off_percent / 100
        return ad_price

    # 根据优惠券修改价格
    def put(self, request, *args, **kwargs):
        res = BaseResponse()
        try:
            user_id = request.user.id
            choose_coupons = request.data.get('choose_coupons')
            global_coupon_id = request.data.get('global_coupon_id')

            total_price_list = []

            ad_price_list = {}

            for course_id, coupon_id in choose_coupons.items():

                buy_key = settings.BUY_KEY % (user_id, course_id)

                # 验证课程是否存在
                buy_info_str = R.get(buy_key)

                if not buy_info_str:
                    raise CommonException(0, '课程不存在')

                buy_info = json.loads(buy_info_str)

                if coupon_id:
                    # 验证优惠券是否存在
                    isHasCoupon = False
                    coupon_info = None
                    for coupon in buy_info['coupons']:
                        if int(coupon_id) == coupon['id']:
                            isHasCoupon = True
                            coupon_info = coupon
                            break
                    if not isHasCoupon:
                        raise CommonException(0, '优惠券不存在')

                    ad_price = self.cal_coupon_price(buy_info['course_info']['price'], coupon_info)
                    total_price_list.append(ad_price)
                    ad_price_list[course_id] = ad_price
                else:
                    course_price = buy_info['course_info']['price']
                    total_price_list.append(course_price)
                    ad_price_list[course_id] = course_price

            total_price = sum(total_price_list)
            total_price_key = settings.TOTAL_PRICE_KEY % user_id

            global_coupons_key = settings.GLOBAL_COUPONS_KEY % user_id
            global_coupons_str = R.get(global_coupons_key)

            # 判断有没有可使用的公共优惠券

            if global_coupon_id:
                if not global_coupons_str:
                    raise CommonException(0, '没有可使用的公共优惠券')

                global_coupon_id = int(global_coupon_id)
                global_coupons_list = json.loads(global_coupons_str)

                # 判断公共优惠券是否存在
                is_has_global_coupons = False
                global_coupon_info = None
                for global_coupon in global_coupons_list:
                    if global_coupon_id == global_coupon['id']:
                        global_coupon_info = global_coupon
                        is_has_global_coupons = True

                if not is_has_global_coupons:
                    raise CommonException(0, '公共优惠券不存在')

                real_payment = self.cal_coupon_price(total_price, global_coupon_info)
            else:
                real_payment = total_price

            total_price_key = settings.TOTAL_PRICE_KEY % user_id
            original_price = json.loads(R.get(total_price_key))
            res.data = {
                'total_price': total_price,
                'real_payment': real_payment,
                'ad_price_list': ad_price_list,
                'deduction': original_price - real_payment
            }

            res.code = 1

        except CommonException as e:
            res.msg = e.msg
        return Response(res.dic)


"""
buy_1_1 = {
	"coupons": [{
		"off_percent": null,
		"id": 1,
		"name": "\u53cc\u5341\u4e00\u767e\u5143\u7acb\u51cf\u52b5",
		"coupon_type_txt": "\u7acb\u51cf\u5238",
		"money_equivalent_value": 100.0,
		"coupon_type": 0,
		"minimum_consume": 0
	}, {
		"off_percent": 50,
		"id": 2,
		"name": "\u53cc\u5341\u4e8c\u4e94\u6298\u4f18\u60e0\u5238",
		"coupon_type_txt": "\u6298\u6263\u5238",
		"money_equivalent_value": null,
		"coupon_type": 2,
		"minimum_consume": 0
	}],
	"course_info": {
		"valid_period_txt": "1\u5468",
		"course_id": 1,
		"name": "Python\u5f00\u53d121\u5929\u5165\u95e8",
		"price_policy": [{
			"valid_period_txt": "1\u5468",
			"price": 100.0,
			"valid_period": 7,
			"id": 1
		}, {
			"valid_period_txt": "2\u5468",
			"price": 200.0,
			"valid_period": 14,
			"id": 2
		}],
		"price_policy_id": 1,
		"price": 100.0,
		"img": "https://hcdn1.luffycity.com/static/frontend/course/5/21%E5%A4%A9_1544059695.5584881.jpeg",
		"valid_period": 7,
	}
}

global_coupons_key_1 = [{
	"off_percent": null,
	"id": 3,
	"name": "618\u6ee1\u51cf\u5238",
	"coupon_type_txt": "\u6ee1\u51cf\u5238",
	"money_equivalent_value": 50.0,
	"coupon_type": 1,
	"minimum_consume": 1000
}]

total_price_key_1 = 100

"""
