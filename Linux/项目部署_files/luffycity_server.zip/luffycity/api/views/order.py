from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import viewsets

from api.models import *
from api.util.auth import TokenAuth
from api.util.response import BaseResponse
from api.util.exceptions import CommonException
from api.serializer.order import OrderSerializers


class MyOrderView(viewsets.ViewSetMixin, APIView):
    authentication_classes = [TokenAuth]

    def list(self, request, *args, **kwargs):
        """
        我的订单列表
        """
        res = BaseResponse()
        try:
            user_id = request.user.id
            order_obj_list = Order.objects.filter(account=request.user)
            ser = OrderSerializers(instance=order_obj_list, many=True)
            res.data = ser.data
            res.code = 1
        except Exception as e:
            res.msg = '获取订单失败'

        return Response(res.dic)
