from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.exceptions import AuthenticationFailed

from django.core.exceptions import ObjectDoesNotExist  # 如果查询不到数据会抛出该错误
from django.conf import settings

from api.util.auth import TokenAuth  # Token认证
from api.util.response import BaseResponse  # 返回给前端的数据结构
from api.util.exceptions import CommonException  # 价格策略的异常类
from api.models import *

import redis
import json

POOL = redis.ConnectionPool(decode_responses=True)
R = redis.Redis(connection_pool=POOL)


class ShoppingCartView(APIView):
    authentication_classes = [TokenAuth]

    # 添加购物车
    def post(self, request, *args, **kwargs):
        """
            模拟请求数据:
            {
                'course_id': 1,  # 课程id
                'price_policy_id': 2  # 价格策略id
            }

            缓存中的购物车的数据结构1:
            redis={
                user_id:{
                    shoppingcar:{
                        "course_id":{
                            "title":"....",
                            "img":"...."
                        }
                        "course_id":{
                            "title":"....",
                            "img":"...."
                        }
                    }
                }
            }

            缓存中的购物车的数据结构2 -> 下面时候的是该结构，在日常开发中推荐使用，因为如果使用结构1，后期很难去操作数据:
            redis={
                shoppingcar_1_1: {
                    "title":"....",
                    "img":"...."
                }
                shoppingcar_1_2: {
                    "title":"....",
                    "img":"...."
                }
            }

        """
        res = BaseResponse()
        # 验证数据
        try:
            # 获取请求数据
            user_id = request.user.id
            course_id = int(request.data.get('course_id'))
            price_policy_id = int(request.data.get('price_policy_id'))

            # 验证课程是否存在，如果不存在会抛出 ObjectDoesNotExist 异常
            course_obj = Course.objects.get(pk=course_id)

            # 生成 course_id 所对应课程的所有价格策略数据
            price_policy_list = []
            for price_policy in course_obj.price_policy.all():
                price_policy_list.append({
                    'id': price_policy.pk,
                    'valid_period': price_policy.valid_period,
                    'valid_period_txt': price_policy.get_valid_period_display(),
                    'price': price_policy.price,
                    'default': price_policy.pk == price_policy_id
                })

            # 验证请求数据中的价格策略是否存在
            if price_policy_id not in [i['id'] for i in price_policy_list]:
                raise CommonException(0, '价格策略不存在')

            pp = PricePolicy.objects.filter(pk=price_policy_id).first()

            # 获取购物车缓存名
            shoppingcar_key = settings.SHOPPINGCAR_KEY % (user_id, course_id)
            # 设置购物车缓存数据
            shoppingcar_val = {
                'course_id': course_id,
                'name': course_obj.name,
                'img': course_obj.course_img,
                'price_policy': price_policy_list,
                'price_policy_id': price_policy_id,
                'price': pp.price,
                'valid_period': pp.valid_period,
                'valid_period_txt': pp.get_valid_period_display()
            }
            # 添加到缓存中
            R.set(shoppingcar_key, json.dumps(shoppingcar_val))
            res.data = '加入购物车成功'

        except ObjectDoesNotExist as e:
            res.msg = '该课程不存在'
        except CommonException as e:
            res.msg = e.msg
        return Response(res.dic)

    # 查看购物车
    def get(self, request, *args, **kwargs):
        res = BaseResponse()
        try:
            # 获取请求数据
            user_id = request.user.id
            shoppingcar_key = settings.SHOPPINGCAR_KEY % (user_id, '*')
            temp = []
            all_car = R.scan_iter(shoppingcar_key)
            for item in all_car:
                temp.append(json.loads(R.get(item)))
            res.data = temp
            res.code = 1
        except Exception as e:
            res.msg = '获取购物车失败'
        return Response(res.dic)

    # 修改购物车
    def put(self, request, *args, **kwargs):
        """
        模拟请求数据:
            {
                'course_id': 1,  # 课程id
                'price_policy_id': 2  # 价格策略id
            }
        """
        res = BaseResponse()
        try:
            user_id = request.user.id
            course_id = request.data.get('course_id')
            price_policy_id = request.data.get('price_policy_id')

            # 验证课程是否存在，如果不存在会抛出 ObjectDoesNotExist 异常
            course_obj = Course.objects.get(pk=course_id)

            shoppingcar_key = settings.SHOPPINGCAR_KEY % (user_id, course_id)
            raise_course = json.loads(R.get(shoppingcar_key))

            # 验证价格策略
            if int(price_policy_id) not in [i['id'] for i in raise_course['price_policy']]:
                raise CommonException(0, '价格策略不存在')

            raise_course['price_policy_id'] = price_policy_id
            raise_course_str = json.dumps(raise_course)
            R.set(shoppingcar_key, raise_course_str)

            res.data = '修改成功'
            res.code = 1

        except ObjectDoesNotExist as e:
            res.msg = '该课程不存在'
        except CommonException as e:
            res.msg = e.msg

        return Response(res.dic)

    # 删除购物车
    def delete(self, request, *args, **kwargs):
        """
        模拟请求数据:
            {
                'course_id': 1,  # 课程id
            }
        """
        res = BaseResponse()
        try:
            user_id = request.user.id
            course_id = request.data.get('course_id')
            shoppingcar_key = settings.SHOPPINGCAR_KEY % (user_id, course_id)
            if not R.exists(shoppingcar_key):
                raise CommonException(0, '删除失败')
            R.delete(shoppingcar_key)
            res.data = '删除成功'
            res.code = 1
        except CommonException as e:
            res.msg = '删除失败'

        return Response(res.dic)
