from django.test import TestCase

import os

if __name__ == '__main__':
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "luffycity.settings")
    import django

    django.setup()

    from django.core.cache import cache

    cache.delete_many(['a', 'b', 'c'])

# R.delete(*R.keys())
