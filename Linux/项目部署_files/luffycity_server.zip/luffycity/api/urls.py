from django.conf.urls import url

from api.views import (
    course,
    signin,
    shopping_cart,
    buy,
    payment,
    order
)

urlpatterns = [
    # 免费课
    url(r'^course/$', course.CourseView.as_view({'get': 'list'})),
    # 免费课详情
    url(r'^course/(?P<pk>\d+)/$', course.CourseView.as_view({'get': 'retrieve'})),
    # 登录
    url(r'^signin/', signin.SigninView.as_view()),
    # 轻课
    url(r'^light_course/', course.LightCourseView.as_view()),
    # 购物车
    url(r'^shoppingcart/', shopping_cart.ShoppingCartView.as_view()),
    # 结算
    url(r'^buy/', buy.BuyView.as_view()),
    # 支付
    url(r'payment/', payment.PaymentView.as_view()),
    # 我的订单
    url(r'^my_order/$', order.MyOrderView.as_view({'get': 'list'})),
]
