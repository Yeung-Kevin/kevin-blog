from django.utils.deprecation import MiddlewareMixin


class CORSMiddleware(MiddlewareMixin):

    def process_response(self, request, response):
        # response["Access-Control-Allow-Origin"] = 'http://127.0.0.1:8001'  # 只允许 http://127.0.0.1:8001 进行跨域请求
        response['Access-Control-Allow-Origin'] = '*'  # 允许所有网址进行跨域请求
        # 处理预检请求
        if request.method == 'OPTIONS':
            response['Access-Control-Allow-Headers'] = 'Content-Type,authorization'  # 允许携带的请求头，response['Access-Control-Allow-Headers'] = 'Content-Type,xx,xxx'
            response['Access-Control-Allow-Methods'] = 'DELETE,PUT'  # 允许发送的请求方式，这里不用添加 GET、POST 请求
            # response['Access-Control-Max-Age'] = 10  # 本次预检请求的有效期，以秒为单位 -> 可以加和不加

        return response
