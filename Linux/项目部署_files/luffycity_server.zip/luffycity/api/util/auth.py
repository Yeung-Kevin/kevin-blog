from rest_framework.authentication import BaseAuthentication
from rest_framework.exceptions import AuthenticationFailed
from rest_framework import status
from api.models import *
from django.core.cache import cache  # Django所提供的缓存功能

import datetime
import pytz


class TokenAuth(BaseAuthentication):
    def authenticate(self, request):

        # ---------------------- 简单版的验证 ------------------------

        # 如果设置了 axios 的公共token，那么就从请求头中获取
        # if request.method == 'OPTIONS':
        #     # 跳出本次认证
        #     return None
        # else:
        #     token = request.META.get('HTTP_AUTHORIZATION')
        #     token_obj = UserToken.objects.filter(token=token).first()
        #     if not token_obj:
        #         raise AuthenticationFailed({'code': 0, 'error': '认证失败'})
        #         # return '', None
        #     return token_obj.user.username, token_obj

        # 如果token是发送过来的那么就从get post 中获取

        # token = request.query_params.get('token')
        # obj = models.UserToken.objects.filter(token=token).first()
        # if not obj:
        #     raise AuthenticationFailed({'code': 1001, 'error': '认证失败'})
        # return (obj.user.user, obj)

        # --------------------------- 复杂版的验证 --------------------------

        if request.method == 'OPTIONS':
            return None
        else:
            token = request.META.get('HTTP_AUTHORIZATION')

            user = cache.get(token)
            if user:
                return user, token

            # 数据库验证：如果缓存中没有token，那么就使用
            token_obj = UserToken.objects.filter(token=token).first()
            if not token_obj:
                raise AuthenticationFailed({'code': 0, 'error': '认证失败'})
                # return '', None

            # 验证token是否在有效期内
            now_time = datetime.datetime.now()
            now_time = now_time.replace(tzinfo=pytz.timezone('UTC'))  # 因为.now()默认获取是不带时区的时间，而从数据库中获取的是带时区的时间所以要给.now()添加上时区
            create_time = token_obj.created
            delta = now_time - create_time  # 相差时间

            if delta < datetime.timedelta(weeks=2):  # 当前时间是否小于两周的时间
                # 校验成功，写入数据库
                delta = datetime.timedelta(weeks=2) - delta  # token 剩余时间
                cache.set(token_obj.token, token_obj.user, min(delta.total_seconds(), 60 * 60 * 24 * 7))  # delta.total_seconds():获取实际的秒数，如果剩余时间超过7天，那么就使用7时间，如果没有则使用剩余的时间，这里的时间不能是写死的
            else:
                raise AuthenticationFailed({'code': 0, 'error': 'token超时'})

            return token_obj.user, token_obj
