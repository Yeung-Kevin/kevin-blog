# 返回给前端的数据结构
class BaseResponse(object):
    def __init__(self):
        self.code = 0
        self.data = None
        self.msg = ''

    @property
    def dic(self):
        return self.__dict__
