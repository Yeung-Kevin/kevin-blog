from django.contrib import admin

# Register your models here.
from .models import *

# 用户表
admin.site.register(UserInfo)
# 用户token表
admin.site.register(UserToken)
# 课程
admin.site.register(Course)
# 课程详情
admin.site.register(CourseDetail)
# 教师
admin.site.register(Teacher)
# 价格表
admin.site.register(PricePolicy)
# 优惠券生成规则
admin.site.register(Coupon)
# 优惠券发放、消费纪录
admin.site.register(CouponRecord)
